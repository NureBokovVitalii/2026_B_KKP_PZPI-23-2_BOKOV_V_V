# setup-node.ps1
# Ensures a working Node.js (>= 22.5) WITHOUT admin rights, on ANY Windows arch.
# Architecture is detected AT RUNTIME (in native PowerShell), so the SAME project
# folder works on x64, ARM64 and x86 machines: each PC gets the matching build.
#
# Order: 0) bundled portable Node in vendor\node-win-<arch> (FULLY OFFLINE, preferred);
#        1) system Node on PATH (if >= 22.5);
#        2) local portable Node in .node\ MATCHING this PC's architecture;
#        3) auto-download the official portable Node.js LTS ZIP for this arch.
#
# A wrong-architecture cache copied from another PC is detected and replaced.
# Result path -> .node\node-path.txt. Exit 0 = success, 1 = failure.
# ASCII-only output for Windows PowerShell 5.1 compatibility.

$ErrorActionPreference = 'Stop'

$root     = Split-Path -Parent $PSScriptRoot      # tools\ -> project root
$nodeHome = Join-Path $root '.node'
$pathFile = Join-Path $nodeHome 'node-path.txt'

# --- Detect THIS machine's architecture (native PowerShell value is authoritative) ---
function Get-Arch {
  $p  = $env:PROCESSOR_ARCHITECTURE
  $p6 = $env:PROCESSOR_ARCHITEW6432
  if ($p -eq 'ARM64' -or $p6 -eq 'ARM64') { return 'arm64' }
  if ($p -eq 'AMD64' -or $p6 -eq 'AMD64') { return 'x64' }
  if ($p -eq 'x86') { return 'x64' }   # 32-bit shell on 64-bit OS -> prefer x64
  return 'x64'
}
$arch = Get-Arch

function Test-NodeOk([string]$exe) {
  if (-not $exe -or -not (Test-Path $exe)) { return $false }
  try {
    $v = & $exe -p 'process.versions.node' 2>$null   # wrong-arch binary fails here
    if (-not $v) { return $false }
    $parts = ($v.Trim()).Split('.')
    $maj = [int]$parts[0]; $min = [int]$parts[1]
    return ($maj -gt 22) -or ($maj -eq 22 -and $min -ge 5)
  } catch { return $false }
}

function Save-Path([string]$p) {
  New-Item -ItemType Directory -Force -Path $nodeHome | Out-Null
  Set-Content -Path $pathFile -Value $p -Encoding ascii -NoNewline
}

# --- 0) Bundled portable Node (vendor\node-win-<arch>) -> fully offline, no download ---
$bundled = Join-Path $root ("vendor\node-win-$arch\node.exe")
if (Test-NodeOk $bundled) {
  $ver = (& $bundled -p 'process.version').Trim()
  Write-Host "[ok] Using bundled Node.js $ver (vendor\node-win-$arch, offline)"
  Save-Path $bundled
  exit 0
}

# --- 1) System Node on PATH ---
$sys = (Get-Command node -ErrorAction SilentlyContinue).Source
if ($sys -and (Test-NodeOk $sys)) {
  $ver = (& $sys -p 'process.version').Trim()
  Write-Host "[ok] Using system Node.js $ver ($arch PC)"
  Save-Path $sys
  exit 0
}
if ($sys) {
  Write-Host "[info] System Node.js is too old (need >= 22.5). Preparing a local copy for $arch."
} else {
  Write-Host "[info] Node.js not found. Preparing a local copy for $arch."
}

# --- 2) Local portable Node in .node\ that MATCHES this PC's architecture ---
# Portable folders are named node-vX.Y.Z-win-<arch>. Accept only the matching arch
# AND verify it actually runs (guards against a cache copied from another PC).
if (Test-Path $nodeHome) {
  $match = Get-ChildItem -Path $nodeHome -Directory -Filter "node-*-win-$arch" -ErrorAction SilentlyContinue |
           ForEach-Object { Join-Path $_.FullName 'node.exe' } |
           Where-Object { Test-NodeOk $_ } | Select-Object -First 1
  if ($match) {
    $ver = (& $match -p 'process.version').Trim()
    Write-Host "[ok] Using local Node.js $ver from .node ($arch)"
    Save-Path $match
    exit 0
  }
  # Remove stale/foreign-arch portable builds so they don't accumulate or confuse.
  Get-ChildItem -Path $nodeHome -Directory -Filter 'node-*-win-*' -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notlike "*-win-$arch" } |
    ForEach-Object {
      Write-Host ("[info] Removing cached Node for another architecture: " + $_.Name)
      Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# --- 3) Download official portable ZIP for this architecture ---
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.ServicePointManager]::SecurityProtocol
} catch {}

Write-Host "[setup] Resolving latest Node.js LTS for win-$arch ..."
$index = Invoke-RestMethod 'https://nodejs.org/dist/index.json'
$lts = ($index | Where-Object { $_.lts }) | Select-Object -First 1
if (-not $lts) { Write-Host '[ERROR] Could not resolve LTS version.'; exit 1 }

$ver  = $lts.version                       # e.g. v24.16.0
$name = "node-$ver-win-$arch"
$url  = "https://nodejs.org/dist/$ver/$name.zip"
Write-Host "[setup] Downloading $name ..."
Write-Host "        $url"

New-Item -ItemType Directory -Force -Path $nodeHome | Out-Null
$zip = Join-Path $nodeHome ($name + '.zip')
try {
  $ProgressPreference = 'SilentlyContinue'
  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
} catch {
  Write-Host ("[ERROR] Download failed: " + $_.Exception.Message)
  Write-Host "        Check Internet, or install Node.js LTS manually: https://nodejs.org/"
  exit 1
}

Write-Host '[setup] Extracting ...'
Expand-Archive -Path $zip -DestinationPath $nodeHome -Force
Remove-Item $zip -Force

$exe = Join-Path $nodeHome ($name + '\node.exe')
if (-not (Test-NodeOk $exe)) {
  $found = Get-ChildItem -Path $nodeHome -Recurse -Filter node.exe -ErrorAction SilentlyContinue |
           Where-Object { Test-NodeOk $_.FullName } | Select-Object -First 1
  if ($found) { $exe = $found.FullName }
}
if (-not (Test-NodeOk $exe)) {
  Write-Host '[ERROR] Downloaded Node did not run on this machine (architecture mismatch?).'
  exit 1
}

$installed = (& $exe -p 'process.version').Trim()
Write-Host "[ok] Installed local Node.js $installed into .node ($arch)"
Save-Path $exe
exit 0
