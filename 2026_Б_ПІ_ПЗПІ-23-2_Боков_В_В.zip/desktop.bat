@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Publication Accounting - desktop window

rem --- 1) Ensure a working Node.js ---
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\setup-node.ps1"
if errorlevel 1 goto :node_error

set "NODE_EXE="
if exist ".node\node-path.txt" set /p NODE_EXE=<".node\node-path.txt"
if not defined NODE_EXE goto :node_error
if not exist "!NODE_EXE!" goto :node_error
for %%d in ("!NODE_EXE!") do set "NODE_DIR=%%~dpd"
set "PATH=!NODE_DIR!;!PATH!"

rem --- 2) Dependencies. goto-style: no parenthesized blocks ---
if exist "node_modules\express" goto :deps_ok
echo [setup] Installing dependencies, please wait ...
call npm install
if errorlevel 1 goto :npm_error
:deps_ok

rem --- Free port 3000 if a previous server is still running (avoids EADDRINUSE) ---
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { $procId=$_.OwningProcess; $p=Get-Process -Id $procId -ErrorAction SilentlyContinue; if ($p -and ($p.ProcessName -eq 'node')) { Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue; Write-Host ('[check] Stopped old server PID ' + $procId) } }"

rem --- Remove leftover browser profile before start (guaranteed clean .appwindow) ---
if exist ".appwindow" rmdir /s /q ".appwindow" 2>nul

echo [desktop] Launching in a desktop window...
"!NODE_EXE!" --experimental-sqlite server\desktop.js

rem --- Clean up browser profile after the window/server stops ---
if exist ".appwindow" rmdir /s /q ".appwindow" 2>nul

echo.
echo [stop] Stopped.
pause
exit /b 0

:node_error
echo [ERROR] Could not prepare Node.js. Install Node.js LTS from https://nodejs.org/
pause
exit /b 1

:npm_error
echo [ERROR] npm install failed. Internet needed once.
pause
exit /b 1
