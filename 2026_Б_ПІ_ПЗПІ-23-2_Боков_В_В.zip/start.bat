@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Publication Accounting - start

echo ============================================================
echo   Publication Accounting (oblik publikatsiy) - start
echo ============================================================
echo.

rem --- 1) Ensure a working Node.js (system / vendor / .node / auto-download) ---
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\setup-node.ps1"
if errorlevel 1 goto :node_error

rem --- 2) Read node.exe path prepared by the helper ---
set "NODE_EXE="
if exist ".node\node-path.txt" set /p NODE_EXE=<".node\node-path.txt"
if not defined NODE_EXE goto :node_error
if not exist "!NODE_EXE!" goto :node_error

rem Add Node folder to PATH so npm works
for %%d in ("!NODE_EXE!") do set "NODE_DIR=%%~dpd"
set "PATH=!NODE_DIR!;!PATH!"
echo [ok] Node: "!NODE_EXE!"
echo.

rem --- 3) Dependencies (express). goto-style: no parenthesized blocks ---
if exist "node_modules\express" goto :deps_ok
echo [setup] Installing dependencies, please wait ...
call npm install
if errorlevel 1 goto :npm_error
:deps_ok
echo [ok] Dependencies ready.
echo.

rem --- 4) Free port 3000 if a previous server is still running (avoids EADDRINUSE) ---
echo [check] Freeing port 3000 if busy ...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { $procId=$_.OwningProcess; $p=Get-Process -Id $procId -ErrorAction SilentlyContinue; if ($p -and ($p.ProcessName -eq 'node')) { Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue; Write-Host ('[check] Stopped old server PID ' + $procId) } }"

rem --- 5) Open browser shortly AFTER the server starts ---
echo [start] Starting server. Browser will open in a few seconds.
start "" /b powershell -NoProfile -Command "Start-Sleep 3; Start-Process 'http://localhost:3000'"

rem --- 6) Run the server. This window keeps the log. Ctrl+C to stop. ---
"!NODE_EXE!" --experimental-sqlite server\index.js

echo.
echo [stop] Server stopped. You can close this window.
pause
exit /b 0

:node_error
echo.
echo [ERROR] Could not prepare Node.js.
echo   Install Node.js LTS x64 manually from https://nodejs.org/ and run start.bat again.
echo.
pause
exit /b 1

:npm_error
echo.
echo [ERROR] npm install failed. Internet is needed once to fetch express.
echo.
pause
exit /b 1
