// Клієнт (ванільний JS). Спілкується з REST API через fetch. Повний CRUD + звітні форми кафедри.
// --- сесія / автентифікація ---
let authToken = localStorage.getItem('pa_token') || null;
let currentUser = null; // { username, role, full_name }
const can = {
  write: () => currentUser && (currentUser.role === 'write' || currentUser.role === 'supervisor'),
  admin: () => currentUser && currentUser.role === 'supervisor',
};

const api = async (method, url, body) => {
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (authToken) headers['Authorization'] = 'Bearer ' + authToken;
  let res;
  try {
    res = await fetch('/api' + url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch (netErr) {
    // мережа недоступна / сервер не відповідає
    throw new Error('Сервер не відповідає (' + (netErr.message || 'network error') + '). Перевірте, що запущено start.bat.');
  }
  // 401 на самому вході — це невірний пароль, а не «сесія завершилася»
  if (res.status === 401 && url !== '/login') { handleSessionExpired(); throw new Error('Потрібна автентифікація'); }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error((data && data.error) || ('HTTP ' + res.status + ' ' + res.statusText));
  }
  return res.status === 204 ? null : res.json();
};
// Пряме завантаження файлів (Excel/Word/CSV/бекап) відбувається переходом за <a href>,
// а звичайна навігація НЕ несе заголовок Authorization. Тому токен передаємо в query (?token=),
// який сервер приймає нарівні з Bearer (див. tokenFromReq у server/auth.js).
const withToken = (url) => authToken ? url + (url.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(authToken) : url;
const el = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; };
const opt = (obj, sel) => Object.entries(obj).map(([k, v]) => `<option value="${k}"${String(k) === String(sel) ? ' selected' : ''}>${v}</option>`).join('');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Випадаючий список років (від поточного+1 до 1990, спадання). placeholder — текст порожнього варіанта.
const CURRENT_YEAR = new Date().getFullYear();
function yearOptions(selected, { placeholder = '—', from = 1990, to = CURRENT_YEAR + 1 } = {}) {
  let html = `<option value="">${esc(placeholder)}</option>`;
  for (let y = to; y >= from; y--) html += `<option value="${y}"${String(y) === String(selected ?? '') ? ' selected' : ''}>${y}</option>`;
  return html;
}

// Універсальні інструменти таблиці: миттєвий пошук по рядках + пейджинг із вибором розміру сторінки.
// Пошук фільтрує рядки за текстом усіх колонок; пейджинг показує по pageSize з відфільтрованого набору.
const PAGE_SIZE = 10;
const PAGE_SIZES = [10, 20, 50, 'all']; // 'all' = показати всі
const PAGE_SIZE_LABELS = { 10: '10', 20: '20', 50: '50', all: 'всі' };
function addRowSearch(card, { placeholder = 'Пошук у таблиці...', pageSize = PAGE_SIZE, searchless = false } = {}) {
  const table = card.querySelector('table');
  if (!table) return;
  const tbody = table.tBodies[0];
  if (!tbody) return;
  const allRows = Array.from(tbody.rows);
  const total = allRows.length;
  const minSize = PAGE_SIZES[0];                 // 10 — мінімальний крок
  const showSearch = !searchless && total >= 2;  // пошук показуємо від 2 рядків
  const showPager = total > minSize;             // пейджинг — коли рядків більше за мінімальний розмір
  if (!showSearch && !showPager) return;

  // знайти прямого нащадка card, який містить таблицю (table може бути в обгортці overflow)
  let anchor = table;
  while (anchor.parentElement && anchor.parentElement !== card) anchor = anchor.parentElement;

  // Панель пошуку (зверху)
  let input = null, counter = null;
  if (showSearch) {
    const bar = el(`<div class="toolbar" style="margin:6px 0 10px">
      <label style="flex:1 1 260px">Пошук<input type="search" class="row-search" placeholder="${esc(placeholder)}" /></label>
      <span class="muted row-search-count"></span>
    </div>`);
    card.insertBefore(bar, anchor);
    input = bar.querySelector('.row-search');
    counter = bar.querySelector('.row-search-count');
  }

  // Поточний розмір сторінки (число або Infinity для «всі»)
  let size = pageSize === Infinity ? Infinity : (Number(pageSize) || PAGE_SIZE);
  let page = 1;

  // Панель пейджингу (під таблицею) із вибором розміру сторінки
  const pager = el(`<div class="pager" style="display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap">
    <button class="btn sec pg-prev">‹ Назад</button>
    <span class="muted pg-info"></span>
    <button class="btn sec pg-next">Далі ›</button>
    <span style="flex:1"></span>
    <label class="inline">На сторінці:
      <select class="pg-size">${PAGE_SIZES.map(s => `<option value="${s}"${(s === 'all' ? size === Infinity : s === size) ? ' selected' : ''}>${PAGE_SIZE_LABELS[s]}</option>`).join('')}</select>
    </label>
  </div>`);
  card.insertBefore(pager, anchor.nextSibling);
  const btnPrev = pager.querySelector('.pg-prev');
  const btnNext = pager.querySelector('.pg-next');
  const pgInfo = pager.querySelector('.pg-info');
  const selSize = pager.querySelector('.pg-size');

  const render = () => {
    const q = input ? input.value.trim().toLowerCase() : '';
    const matched = allRows.filter(tr => !q || tr.textContent.toLowerCase().includes(q));
    const per = size === Infinity ? Math.max(matched.length, 1) : size;
    const pages = Math.max(1, Math.ceil(matched.length / per));
    if (page > pages) page = pages;
    const start = (page - 1) * per, end = start + per;
    for (const tr of allRows) tr.style.display = 'none';
    matched.slice(start, end).forEach(tr => { tr.style.display = ''; });
    if (counter) counter.textContent = q ? `Знайдено: ${matched.length} з ${total}` : '';
    // пейджер показуємо, якщо рядків більше за мінімальний розмір (щоб був доступний вибір розміру)
    if (matched.length > minSize) {
      pager.style.display = 'flex';
      const navVisible = size !== Infinity && pages > 1;
      btnPrev.style.display = btnNext.style.display = navVisible ? '' : 'none';
      pgInfo.textContent = size === Infinity
        ? `Показано всі ${matched.length}`
        : `Сторінка ${page} з ${pages} · показано ${matched.length ? start + 1 : 0}–${Math.min(end, matched.length)} з ${matched.length}`;
      btnPrev.disabled = page <= 1;
      btnNext.disabled = page >= pages;
    } else {
      pager.style.display = 'none';
    }
  };
  btnPrev.onclick = () => { if (page > 1) { page--; render(); } };
  btnNext.onclick = () => { page++; render(); };
  selSize.onchange = () => { size = selSize.value === 'all' ? Infinity : Number(selSize.value); page = 1; render(); };
  if (input) input.addEventListener('input', () => { page = 1; render(); });
  render();
}

let META = {};
const cache = {};
const load = async () => {
  [cache.authors, cache.orgs, cache.venues, cache.specialties] = await Promise.all([
    api('GET', '/authors'), api('GET', '/organizations'), api('GET', '/venues'), api('GET', '/specialties'),
  ]);
};

document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => switchTab(b.dataset.tab));
const TABS = {
  publications: () => renderPublications(),
  authors: () => renderAuthors(),
  exhibitions: () => renderExhibitions(),
  patents: () => renderPatents(),
  developments: () => renderDevelopments(),
  reports: renderReports,
  dictionaries: () => renderDictionaries(),
  backup: () => renderBackup(),
};
function switchTab(name) {
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach(s => s.classList.add('hidden'));
  document.getElementById('tab-' + name).classList.remove('hidden');
  TABS[name]();
  refreshSummary();
}

async function refreshSummary() {
  const s = await api('GET', '/reports/summary');
  document.getElementById('summary').innerHTML =
    `<span>Публікацій: ${s.publications}</span><span>Статей: ${s.articles}</span><span>Тез: ${s.theses}</span>` +
    `<span>Доповідей: ${s.reports}</span><span>Scopus: ${s.scopus}</span><span>З іноземними: ${s.with_foreign}</span>` +
    `<span>З авторами &lt;35: ${s.with_young}</span><span>Авторів: ${s.authors}</span>` +
    `<span>Виставок: ${s.exhibitions}</span><span>Патентів: ${s.patents}</span><span>Розробок: ${s.developments}</span>`;
}

// ---------- ПУБЛІКАЦІЇ ----------
const pubFilter = { search: '', type: '', category: '', year_from: '', year_to: '', author_id: '', scopus: false, foreign: false };
function pubFilterQuery() {
  const p = new URLSearchParams();
  if (pubFilter.search) p.set('search', pubFilter.search);
  if (pubFilter.type) p.set('type', pubFilter.type);
  if (pubFilter.category) p.set('category', pubFilter.category);
  if (pubFilter.year_from) p.set('year_from', pubFilter.year_from);
  if (pubFilter.year_to) p.set('year_to', pubFilter.year_to);
  if (pubFilter.author_id) p.set('author_id', pubFilter.author_id);
  if (pubFilter.scopus) p.set('scopus', '1');
  if (pubFilter.foreign) p.set('foreign', '1');
  const s = p.toString();
  return s ? '?' + s : '';
}
async function renderPublications(editId = null, keepFocus = null) {
  await load();
  const pubs = await api('GET', '/publications' + pubFilterQuery());
  const editing = editId ? (await api('GET', '/publications/' + editId)) : null;
  const root = document.getElementById('tab-publications');
  root.innerHTML = '';

  // Панель пошуку/фільтра (UC-5)
  const active = pubFilterQuery() !== '';
  const filter = el(`<div class="card"><h2>Пошук / фільтр</h2>
    <div class="toolbar">
      <label style="flex:1 1 260px">Пошук (назва, автор, видання, DOI, ключові слова)<input id="fl-search" value="${esc(pubFilter.search)}" placeholder="введіть текст..." /></label>
      <label>Тип<select id="fl-type"><option value="">усі</option>${opt(META.pub_types, pubFilter.type)}</select></label>
      <label>Категорія<select id="fl-cat"><option value="">усі</option>${opt(META.pub_categories, pubFilter.category)}</select></label>
      <label>Автор<select id="fl-author"><option value="">усі</option>${cache.authors.map(a => `<option value="${a.id}"${pubFilter.author_id == a.id ? ' selected' : ''}>${esc(a.full_name_uk)}</option>`).join('')}</select></label>
      <label>Рік з<select id="fl-yf" style="min-width:90px">${yearOptions(pubFilter.year_from, { placeholder: 'будь-який' })}</select></label>
      <label>Рік по<select id="fl-yt" style="min-width:90px">${yearOptions(pubFilter.year_to, { placeholder: 'будь-який' })}</select></label>
      <label class="inline">Scopus/WoS <input type="checkbox" id="fl-scopus"${pubFilter.scopus ? ' checked' : ''}/></label>
      <label class="inline">Іноземні <input type="checkbox" id="fl-foreign"${pubFilter.foreign ? ' checked' : ''}/></label>
      <button class="btn" id="fl-apply" style="align-self:flex-end">Застосувати</button>
      ${active ? '<button class="btn sec" id="fl-clear" style="align-self:flex-end">Скинути</button>' : ''}
    </div>
    ${active ? `<div class="muted">Знайдено: ${pubs.length}</div>` : ''}
  </div>`);
  const applyFilter = (keepFocus) => {
    pubFilter.search = filter.querySelector('#fl-search').value.trim();
    pubFilter.type = filter.querySelector('#fl-type').value;
    pubFilter.category = filter.querySelector('#fl-cat').value;
    pubFilter.author_id = filter.querySelector('#fl-author').value;
    pubFilter.year_from = filter.querySelector('#fl-yf').value;
    pubFilter.year_to = filter.querySelector('#fl-yt').value;
    pubFilter.scopus = filter.querySelector('#fl-scopus').checked;
    pubFilter.foreign = filter.querySelector('#fl-foreign').checked;
    renderPublications(null, keepFocus);
  };
  // Живий фільтр: миттєво при зміні select/checkbox/року і з невеликою затримкою при наборі тексту.
  filter.querySelector('#fl-apply').onclick = () => applyFilter();
  filter.querySelector('#fl-search').addEventListener('input', () => {
    clearTimeout(window.__pubSearchT);
    window.__pubSearchT = setTimeout(() => applyFilter('search'), 350);
  });
  filter.querySelector('#fl-search').addEventListener('keydown', (e) => { if (e.key === 'Enter') { clearTimeout(window.__pubSearchT); applyFilter('search'); } });
  ['#fl-type', '#fl-cat', '#fl-author', '#fl-yf', '#fl-yt', '#fl-scopus', '#fl-foreign'].forEach(sel => {
    filter.querySelector(sel).addEventListener('change', () => applyFilter());
  });
  if (active) filter.querySelector('#fl-clear').onclick = () => {
    Object.assign(pubFilter, { search: '', type: '', category: '', year_from: '', year_to: '', author_id: '', scopus: false, foreign: false });
    renderPublications();
  };
  root.appendChild(filter);
  // Повернути фокус у поле пошуку після живого ререндеру
  if (keepFocus === 'search') {
    const inp = filter.querySelector('#fl-search');
    inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length);
  }

  const chk = (id, on) => `<label class="chk"><input type="checkbox" id="${id}"${on ? ' checked' : ''}/> </label>`;
  const form = el(`<details class="card collapsible"${editing ? ' open' : ''}><summary><span class="summary-title">${editing ? 'Редагування публікації #' + editing.id : '+ Нова публікація'}</span><span class="summary-hint"></span></summary>
    <div class="row" style="margin-top:12px">
      <label style="flex:1 1 100%">Назва<input id="p-title" placeholder="Назва роботи" /></label>
      <label>Тип<select id="p-type">${opt(META.pub_types, editing?.type)}</select></label>
      <label>Звітна категорія<select id="p-cat"><option value="">—</option>${opt(META.pub_categories, editing?.category)}</select></label>
      <label>Видання/конференція<select id="p-venue"><option value="">—</option>${cache.venues.map(v => `<option value="${v.id}"${editing?.venue_id == v.id ? ' selected' : ''}>${esc(v.name)}</option>`).join('')}</select></label>
      <label>Рік<select id="p-year" style="min-width:90px">${yearOptions(editing?.year ?? CURRENT_YEAR, { placeholder: '—' })}</select></label>
      <label>Мова<select id="p-lang">${opt(META.languages, editing?.language || 'uk')}</select></label>
      <label>Місце видання<input id="p-place" /></label>
      <label>Том/випуск<input id="p-vol" style="min-width:110px" /></label>
      <label>Стор. з<input id="p-pf" type="number" style="min-width:70px" /></label>
      <label>Стор. по<input id="p-pt" type="number" style="min-width:70px" /></label>
      <label>DOI<input id="p-doi" /></label>
      <label>Посилання<input id="p-url" /></label>
      <label>Наукометр. база / ІФ<input id="p-scib" placeholder="напр. Scopus" /></label>
      <label>Цитувань<input id="p-cit" type="number" style="min-width:80px" /></label>
    </div>
    <div class="row" style="align-items:center;margin-top:6px">
      <label class="inline">Scopus <input type="checkbox" id="p-scopus"${editing?.scopus ? ' checked' : ''}/></label>
      <label class="inline">WoS <input type="checkbox" id="p-wos"${editing?.wos ? ' checked' : ''}/></label>
      <label class="inline">Фахове <input type="checkbox" id="p-prof"${editing?.is_professional ? ' checked' : ''}/></label>
      <label class="inline">Імпакт-фактор <input type="checkbox" id="p-if"${editing?.impact_factor ? ' checked' : ''}/></label>
      <label class="inline">Гриф МОН <input type="checkbox" id="p-gryf"${editing?.gryf_mon ? ' checked' : ''}/></label>
    </div>
    <div class="row"><label style="flex:1 1 100%">Ключові слова<input id="p-kw" /></label></div>
    <div class="row"><label style="flex:1 1 100%">Анотація<textarea id="p-abstract"></textarea></label></div>
    <h2 style="margin-top:14px">Співавтори</h2>
    <div class="toolbar">
      <label>Автор<select id="p-author">${cache.authors.map(a => `<option value="${a.id}">${esc(a.full_name_uk)}</option>`).join('')}</select></label>
      <label>Роль<select id="p-arole">${opt(META.pub_author_roles)}</select></label>
      <label class="inline">Студент <input type="checkbox" id="p-astud"/></label>
      <label class="inline">Доповідав <input type="checkbox" id="p-apres"/></label>
      <button class="btn sec" id="p-add-author">Додати співавтора</button>
    </div>
    <div id="p-authors-list"></div>
    <div style="margin-top:12px">
      <button class="btn" id="p-save">${editing ? 'Оновити публікацію' : 'Зберегти публікацію'}</button>
      ${editing ? '<button class="btn sec" id="p-cancel">Скасувати</button>' : ''}
    </div>
  </details>`);
  root.appendChild(form);

  const g = (id) => form.querySelector(id);
  if (editing) {
    g('#p-title').value = editing.title || ''; g('#p-year').value = editing.year ?? '';
    g('#p-place').value = editing.place || ''; g('#p-vol').value = editing.volume_issue || '';
    g('#p-pf').value = editing.page_from ?? ''; g('#p-pt').value = editing.page_to ?? '';
    g('#p-doi').value = editing.doi ?? ''; g('#p-url').value = editing.url ?? '';
    g('#p-scib').value = editing.scimetric_base ?? ''; g('#p-cit').value = editing.citations ?? 0;
    g('#p-kw').value = editing.keywords ?? ''; g('#p-abstract').value = editing.abstract ?? '';
    g('#p-cancel').onclick = () => renderPublications();
  }

  const chosen = editing ? editing.authors.map(a => ({ author_id: a.author_id, role_in_pub: a.role_in_pub, is_student: a.is_student, presented: a.presented })) : [];
  const redraw = () => {
    g('#p-authors-list').innerHTML = chosen.map((c, i) => {
      const a = cache.authors.find(x => x.id == c.author_id);
      const t = [META.pub_author_roles[c.role_in_pub]]; if (c.is_student) t.push('студ'); if (c.presented) t.push('доповідав');
      return `<span class="pill">${esc(a?.full_name_uk || '?')} · ${t.join(' · ')}<button data-i="${i}">x</button></span>`;
    }).join('') || '<span class="muted">Ще не додано співавторів</span>';
    g('#p-authors-list').querySelectorAll('button').forEach(b => b.onclick = () => { chosen.splice(+b.dataset.i, 1); redraw(); });
  };
  redraw();
  g('#p-add-author').onclick = () => {
    chosen.push({ author_id: +g('#p-author').value, role_in_pub: g('#p-arole').value, is_student: g('#p-astud').checked, presented: g('#p-apres').checked });
    g('#p-astud').checked = false; g('#p-apres').checked = false; redraw();
  };
  g('#p-save').onclick = async () => {
    const body = {
      title: g('#p-title').value, type: g('#p-type').value, category: g('#p-cat').value || null,
      venue_id: g('#p-venue').value ? +g('#p-venue').value : null, year: g('#p-year').value ? +g('#p-year').value : null,
      language: g('#p-lang').value, place: g('#p-place').value || null, volume_issue: g('#p-vol').value || null,
      page_from: g('#p-pf').value ? +g('#p-pf').value : null, page_to: g('#p-pt').value ? +g('#p-pt').value : null,
      doi: g('#p-doi').value || null, url: g('#p-url').value || null, scimetric_base: g('#p-scib').value || null,
      citations: g('#p-cit').value ? +g('#p-cit').value : 0, keywords: g('#p-kw').value || null, abstract: g('#p-abstract').value || null,
      scopus: g('#p-scopus').checked, wos: g('#p-wos').checked, is_professional: g('#p-prof').checked,
      impact_factor: g('#p-if').checked, gryf_mon: g('#p-gryf').checked, authors: chosen,
    };
    if (!body.title) return alert('Вкажіть назву');
    try { editing ? await api('PUT', '/publications/' + editing.id, body) : await api('POST', '/publications', body); renderPublications(); }
    catch (e) { alert('Помилка: ' + e.message); }
  };

  const authTags = (p) => p.authors.map(a => {
    const t = [];
    if (a.is_student) t.push('<span class="tag stud">студ</span>');
    if (a.role_in_pub === 'advisor') t.push('<span class="tag adv">керівн</span>');
    if (a.is_foreign) t.push('<span class="tag foreign">іноз.</span>');
    if (a.under35) t.push('<span class="tag young">&lt;35</span>');
    return `${esc(a.name_uk)} ${t.join('')}`;
  }).join('<br>');

  const list = el(`<div class="card"><h2>Публікації (${pubs.length})</h2>
    <table><thead><tr>
      <th>Назва</th><th>Категорія</th><th>Видання</th><th>Рік</th><th>Стор.</th><th>Авт.арк.</th><th>Автори</th><th>Ознаки</th><th></th>
    </tr></thead><tbody>${pubs.map(p => `<tr>
      <td>${esc(p.title)}${p.doi ? `<br><span class="muted">DOI: ${esc(p.doi)}</span>` : ''}</td>
      <td><span class="muted">${esc((META.pub_categories[p.category] || '').replace(/^[IVX]+\. /, '') || '—')}</span></td>
      <td>${esc(p.venue_name || '')}</td>
      <td>${p.year ?? ''}</td>
      <td>${p.pages ?? ''}</td>
      <td>${p.author_sheets ? `${p.author_sheets.decimal} <span class="muted">(${p.author_sheets.fraction})</span>` : ''}</td>
      <td>${authTags(p)}</td>
      <td>${p.scopus ? '<span class="tag scopus">Scopus</span>' : ''}${p.wos ? '<span class="tag scopus">WoS</span>' : ''}${p.is_professional ? '<span class="tag stud">фах.</span>' : ''}${p.has_foreign ? '<span class="tag foreign">іноз.</span>' : ''}</td>
      <td style="white-space:nowrap"><button class="btn sec" data-edit="${p.id}">Ред.</button> <button class="btn danger" data-del="${p.id}">x</button></td>
    </tr>`).join('')}</tbody></table></div>`);
  root.appendChild(list);
  list.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { renderPublications(b.dataset.edit); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  list.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (confirm('Видалити публікацію?')) { await api('DELETE', '/publications/' + b.dataset.del); renderPublications(); } });
  addRowSearch(list, { searchless: true }); // лише пейджинг (пошук — у серверному фільтрі вище)
}

// ---------- АВТОРИ ----------
async function renderAuthors(editId = null) {
  await load();
  const editing = editId ? cache.authors.find(a => a.id == editId) : null;
  const root = document.getElementById('tab-authors');
  const form = el(`<details class="card collapsible"${editing ? ' open' : ''}><summary><span class="summary-title">${editing ? 'Редагування автора #' + editing.id : '+ Новий автор / особа'}</span><span class="summary-hint"></span></summary><div class="row" style="margin-top:12px">
    <label>ПІБ (укр.)<input id="a-uk" /></label>
    <label>ПІБ (англ.)<input id="a-en" /></label>
    <label>Роль<select id="a-role">${opt(META.author_roles, editing?.role)}</select></label>
    <label>Рік народж.<select id="a-by" style="min-width:90px">${yearOptions(editing?.birth_year, { placeholder: '—', from: 1940, to: CURRENT_YEAR })}</select></label>
    <label>Організація<select id="a-org"><option value="">—</option>${cache.orgs.map(o => `<option value="${o.id}"${editing?.organization_id == o.id ? ' selected' : ''}>${esc(o.name)}</option>`).join('')}</select></label>
    <label class="inline">Іноземний <input type="checkbox" id="a-foreign"${editing?.is_foreign ? ' checked' : ''}/></label>
    <label>Вчене звання<input id="a-title" /></label>
    <label>ORCID<input id="a-orcid" /></label>
    <label>Scopus ID<input id="a-scopus" /></label>
    <label>Researcher ID<input id="a-rid" /></label>
    <label>Google Scholar<input id="a-gs" /></label>
    <button class="btn" id="a-save" style="align-self:flex-end">${editing ? 'Оновити' : 'Додати'}</button>
    ${editing ? '<button class="btn sec" id="a-cancel" style="align-self:flex-end">Скасувати</button>' : ''}
  </div></details>`);
  const g = (id) => form.querySelector(id);
  if (editing) {
    g('#a-uk').value = editing.full_name_uk || ''; g('#a-en').value = editing.full_name_en || '';
    g('#a-by').value = editing.birth_year ?? ''; g('#a-title').value = editing.academic_title || '';
    g('#a-orcid').value = editing.orcid || ''; g('#a-scopus').value = editing.scopus_id || '';
    g('#a-rid').value = editing.researcher_id || ''; g('#a-gs').value = editing.google_scholar || '';
    g('#a-cancel').onclick = () => renderAuthors();
  }
  g('#a-save').onclick = async () => {
    if (!g('#a-uk').value) return alert('Вкажіть ПІБ');
    const body = {
      full_name_uk: g('#a-uk').value, full_name_en: g('#a-en').value || null, role: g('#a-role').value,
      birth_year: g('#a-by').value ? +g('#a-by').value : null, organization_id: g('#a-org').value ? +g('#a-org').value : null,
      is_foreign: g('#a-foreign').checked, academic_title: g('#a-title').value || null,
      orcid: g('#a-orcid').value || null, scopus_id: g('#a-scopus').value || null,
      researcher_id: g('#a-rid').value || null, google_scholar: g('#a-gs').value || null,
    };
    try { editing ? await api('PUT', '/authors/' + editing.id, body) : await api('POST', '/authors', body); renderAuthors(); }
    catch (e) { alert('Помилка: ' + e.message); }
  };
  const list = el(`<div class="card"><h2>Автори (${cache.authors.length})</h2>
    <table><thead><tr><th>ПІБ</th><th>Англ.</th><th>Роль</th><th>Рік нар.</th><th>Організація</th><th>Профілі</th><th></th></tr></thead>
    <tbody>${cache.authors.map(a => `<tr>
      <td>${esc(a.full_name_uk)}</td><td class="muted">${esc(a.full_name_en || '')}</td>
      <td>${META.author_roles[a.role] || a.role}</td><td>${a.birth_year ?? ''}</td>
      <td>${esc(a.org_name || '')}</td>
      <td class="muted">${[a.orcid && 'ORCID', a.scopus_id && 'Scopus', a.researcher_id && 'RID', a.google_scholar && 'GS'].filter(Boolean).join(', ')}${a.is_foreign ? ' <span class="tag foreign">іноз.</span>' : ''}</td>
      <td style="white-space:nowrap"><button class="btn sec" data-edit="${a.id}">Ред.</button> <button class="btn sec" data-rename="${a.id}">Зміна ПІБ</button> <button class="btn danger" data-del="${a.id}">x</button></td></tr>`).join('')}</tbody></table></div>`);
  list.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { renderAuthors(b.dataset.edit); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  list.querySelectorAll('[data-rename]').forEach(b => b.onclick = () => renameAuthor(b.dataset.rename));
  list.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (confirm('Видалити автора?')) { await api('DELETE', '/authors/' + b.dataset.del); renderAuthors(); } });
  addRowSearch(list, { placeholder: 'ПІБ, організація, профіль...' });
  root.innerHTML = ''; root.appendChild(form); root.appendChild(list);
}

// UC-2: фіксація зміни ПІБ автора (зі збереженням історії)
async function renameAuthor(id) {
  const a = cache.authors.find(x => x.id == id);
  if (!a) return;
  const history = await api('GET', `/authors/${id}/history`);
  const root = document.getElementById('tab-authors');
  const card = el(`<div class="card"><h2>Зміна ПІБ: ${esc(a.full_name_uk)}</h2>
    <div class="toolbar">
      <label>Нове ПІБ<input id="rn-new" value="${esc(a.full_name_uk)}" /></label>
      <label>Дата зміни<input id="rn-date" type="date" /></label>
      <button class="btn" id="rn-save" style="align-self:flex-end">Зберегти зміну</button>
      <button class="btn sec" id="rn-cancel" style="align-self:flex-end">Скасувати</button>
    </div>
    <p class="muted">При збереженні поточне ПІБ переходить в історію, а в картці автора встановлюється нове. Списки публікацій лишаються повʼязаними (за id автора).</p>
    ${history.length ? `<h2 style="margin-top:10px">Історія змін</h2>
      <table><thead><tr><th>Було</th><th>Стало</th><th>Дата</th></tr></thead>
      <tbody>${history.map(h => `<tr><td>${esc(h.old_name)}</td><td>${esc(h.new_name)}</td><td>${esc(h.changed_on || '')}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">Історія порожня.</p>'}
  </div>`);
  card.querySelector('#rn-cancel').onclick = () => renderAuthors();
  card.querySelector('#rn-save').onclick = async () => {
    const newName = card.querySelector('#rn-new').value.trim();
    if (!newName) return alert('Вкажіть нове ПІБ');
    if (newName === a.full_name_uk) return alert('ПІБ не змінилося');
    try {
      await api('POST', `/authors/${id}/rename`, { new_name: newName, changed_on: card.querySelector('#rn-date').value || null });
      await load();
      renderAuthors();
    } catch (e) { alert('Помилка: ' + e.message); }
  };
  root.innerHTML = ''; root.appendChild(card);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---------- Узагальнений CRUD для простих сутностей (виставки/патенти/розробки) ----------
async function simpleCrud(opts) {
  const { tabId, route, title, fields, editId } = opts;
  const items = await api('GET', route);
  const editing = editId ? items.find(x => x.id == editId) : null;
  const root = document.getElementById(tabId);
  const fieldHtml = fields.map(f => {
    const val = editing ? (editing[f.key] ?? '') : (f.def ?? '');
    if (f.type === 'select') return `<label>${f.label}<select id="f-${f.key}">${opt(f.options, val)}</select></label>`;
    if (f.type === 'year') return `<label>${f.label}<select id="f-${f.key}" style="min-width:90px">${yearOptions(val, { placeholder: '—' })}</select></label>`;
    if (f.type === 'date') return `<label>${f.label}<input id="f-${f.key}" type="date" value="${esc(val)}" /></label>`;
    if (f.type === 'textarea') return `<label style="flex:1 1 100%">${f.label}<textarea id="f-${f.key}">${esc(val)}</textarea></label>`;
    const t = f.type === 'number' ? 'number' : 'text';
    return `<label${f.wide ? ' style="flex:1 1 100%"' : ''}>${f.label}<input id="f-${f.key}" type="${t}" value="${esc(val)}" /></label>`;
  }).join('');
  const form = el(`<details class="card collapsible"${editing ? ' open' : ''}><summary><span class="summary-title">${editing ? title + ' — редагування #' + editing.id : '+ ' + title + ' — новий запис'}</span><span class="summary-hint"></span></summary>
    <div class="row" style="margin-top:12px">${fieldHtml}</div>
    <div style="margin-top:10px"><button class="btn" id="f-save">${editing ? 'Оновити' : 'Додати'}</button>
    ${editing ? '<button class="btn sec" id="f-cancel">Скасувати</button>' : ''}</div></details>`);
  if (editing) form.querySelector('#f-cancel').onclick = () => simpleCrud({ ...opts, editId: null });
  form.querySelector('#f-save').onclick = async () => {
    const body = {};
    for (const f of fields) {
      const v = form.querySelector('#f-' + f.key).value;
      body[f.key] = (f.type === 'number' || f.type === 'year') ? (v ? +v : null) : (v || null);
    }
    if (fields[0] && !body[fields[0].key] && !body[(fields[1] || {}).key]) return alert('Заповніть обовʼязкові поля');
    try {
      editing ? await api('PUT', `${route}/${editing.id}`, body) : await api('POST', route, body);
      simpleCrud({ ...opts, editId: null });
    } catch (e) { alert('Помилка: ' + e.message); }
  };
  const cols = fields.filter(f => f.inList !== false);
  const list = el(`<div class="card"><h2>${title} (${items.length})</h2>
    <table><thead><tr>${cols.map(f => `<th>${f.label}</th>`).join('')}<th></th></tr></thead>
    <tbody>${items.map(it => `<tr>${cols.map(f => {
      let v = it[f.key];
      if (f.type === 'select' && f.options) v = f.options[v] ?? v;
      return `<td>${esc(v ?? '')}</td>`;
    }).join('')}<td style="white-space:nowrap"><button class="btn sec" data-edit="${it.id}">Ред.</button> <button class="btn danger" data-del="${it.id}">x</button></td></tr>`).join('')}</tbody></table></div>`);
  list.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { simpleCrud({ ...opts, editId: b.dataset.edit }); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  list.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (confirm('Видалити запис?')) { await api('DELETE', `${route}/${b.dataset.del}`); simpleCrud({ ...opts, editId: null }); } });
  addRowSearch(list);
  root.innerHTML = ''; root.appendChild(form); root.appendChild(list);
}

const renderExhibitions = () => simpleCrud({
  tabId: 'tab-exhibitions', route: '/exhibitions', title: 'VIII. Виставки',
  fields: [
    { key: 'exhibit_name', label: 'Експонат', wide: true },
    { key: 'developers', label: 'Розроблювачі (ПІБ)', wide: true },
    { key: 'exhibition_name', label: 'Назва виставки' },
    { key: 'date_place', label: 'Дата й місце' },
    { key: 'awards', label: 'Нагороди' },
    { key: 'year', label: 'Рік', type: 'year' },
  ],
});
const renderPatents = () => simpleCrud({
  tabId: 'tab-patents', route: '/patents', title: 'IX. Патенти / охоронні документи',
  fields: [
    { key: 'title', label: 'Назва / опис', wide: true },
    { key: 'theme_no', label: '№ / реєстраційні дані', wide: true },
    { key: 'count', label: 'К-сть', type: 'number', def: 1 },
    { key: 'kind', label: 'Тип', type: 'select', options: META.patent_kinds },
    { key: 'supervisor', label: 'Науковий керівник' },
    { key: 'year', label: 'Рік', type: 'year' },
  ],
});
const renderDevelopments = () => simpleCrud({
  tabId: 'tab-developments', route: '/developments', title: 'Розробки, впроваджені поза університетом',
  fields: [
    { key: 'title_authors', label: 'Назва та автори', wide: true },
    { key: 'indicators', label: 'Показники / переваги / ефект', type: 'textarea', inList: false },
    { key: 'place', label: 'Місце впровадження', wide: true },
    { key: 'act_date', label: 'Дата акту', type: 'date' },
    { key: 'results', label: 'Практичні результати', type: 'textarea', inList: false },
    { key: 'framework', label: 'У рамках' },
    { key: 'year', label: 'Рік', type: 'year' },
  ],
});

// ---------- ЗВІТИ ----------
async function renderReports() {
  await load();
  const root = document.getElementById('tab-reports');
  const groups = [
    {
      h: 'Звітні форми кафедри', items: [
        { key: 'article_ua', title: 'I. Статті в Україні' },
        { key: 'article_foreign', title: 'II. Статті за кордоном' },
        { key: 'conf_ua', title: 'III. Конференції в Україні' },
        { key: 'conf_foreign', title: 'IV. Конференції за кордоном' },
        { key: 'prep_foreign', title: 'V. Підготовлені до друку' },
        { key: 'monograph', title: 'VI. Монографії' },
        { key: 'textbook', title: 'VII. Підручники' },
        { key: 'exhibitions', title: 'VIII. Виставки' },
        { key: 'patents', title: 'IX. Патенти' },
        { key: 'developments', title: 'Розробки' },
      ]
    },
    {
      h: 'Зведені / аналітичні', items: [
        { key: 'all-works', title: 'Перелік праць (усі)' },
        { key: 'scopus', title: 'Scopus / WoS' },
        { key: 'foreign', title: 'З іноземними співавторами' },
        { key: 'by-age', title: 'За віком (<35)' },
        { key: 'by-year', title: 'За роками' },
      ]
    },
  ];
  // Параметри звіту (UC-3): період + автор. Прокидуються у перегляд та усі експорти.
  const reportParams = () => {
    const p = new URLSearchParams();
    const yf = root.querySelector('#rp-yf')?.value, yt = root.querySelector('#rp-yt')?.value, au = root.querySelector('#rp-author')?.value;
    if (yf) p.set('year_from', yf); if (yt) p.set('year_to', yt); if (au) p.set('author_id', au);
    return p.toString();
  };
  const withParams = (url) => { const pr = reportParams(); return pr ? url + (url.includes('?') ? '&' : '?') + pr : url; };

  root.innerHTML = `<div class="card"><h2>Звіти</h2>
    <div class="toolbar" style="background:#f1f4fb;border:1px solid var(--border);border-radius:8px;padding:8px">
      <label>Період: рік з<select id="rp-yf" style="min-width:90px">${yearOptions('', { placeholder: 'будь-який' })}</select></label>
      <label>по<select id="rp-yt" style="min-width:90px">${yearOptions('', { placeholder: 'будь-який' })}</select></label>
      <label>Автор (викладач)<select id="rp-author"><option value="">усі</option>${cache.authors.map(a => `<option value="${a.id}">${esc(a.full_name_uk)}</option>`).join('')}</select></label>
      <a class="btn" id="rp-xlsx-all" href="${withToken('/api/export/xlsx')}">Експорт УСІХ форм у Excel</a>
    </div>
    ${groups.map(grp => `<div class="muted" style="margin:8px 0 4px">${grp.h}</div>
      <div class="report-buttons">${grp.items.map(d => `<button class="btn sec" data-r="${d.key}">${d.title}</button>`).join('')}</div>`).join('')}
    <div id="report-out" style="margin-top:12px"><span class="muted">Оберіть звіт. Параметри період/автор застосовуються до публікаційних форм.</span></div></div>`;

  // Кнопка «усі форми» підхоплює параметри на момент кліку
  root.querySelector('#rp-xlsx-all').addEventListener('click', (e) => { e.currentTarget.href = withToken(withParams('/api/export/xlsx')); });

  root.querySelectorAll('[data-r]').forEach(b => b.onclick = async () => {
    const key = b.dataset.r;
    const rows = await api('GET', withParams('/api/reports/' + key).replace('/api', ''));
    const out = root.querySelector('#report-out');
    const exportBar = `<div class="toolbar">
        <a class="btn" href="${withToken(withParams('/api/reports/' + key + '?format=xlsx'))}">Експорт Excel (.xlsx)</a>
        <a class="btn sec" href="${withToken(withParams('/api/reports/' + key + '?format=docx'))}">Експорт Word (.docx)</a>
        <a class="btn sec" href="${withToken(withParams('/api/reports/' + key + '?format=csv'))}">Експорт CSV</a>
      </div>`;
    if (!rows.length) { out.innerHTML = exportBar + '<span class="muted">Немає даних для цієї форми за обраними параметрами.</span>'; return; }
    const cols = Object.keys(rows[0]);
    out.innerHTML = exportBar +
      `<div style="overflow:auto"><table><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead>
      <tbody>${rows.map(r => `<tr>${cols.map(c => `<td>${esc(r[c])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    addRowSearch(out, { placeholder: 'пошук у звіті...' });
  });
}

// ---------- РЕЗЕРВНА КОПІЯ / ВІДНОВЛЕННЯ БД ----------
const TABLE_LABELS = {
  organizations: 'Організації', specialties: 'Спеціальності', venues: 'Видання/конференції',
  authors: 'Автори', publications: 'Публікації', publication_authors: 'Авторство',
  name_history: 'Історія ПІБ', exhibitions: 'Виставки', patents: 'Патенти', developments: 'Розробки',
};
async function renderBackup() {
  const root = document.getElementById('tab-backup');
  const stats = await api('GET', '/export/db/stats');
  const total = Object.values(stats).reduce((a, b) => a + b, 0);
  root.innerHTML = `
    <div class="card"><h2>Резервна копія бази даних</h2>
      <p class="muted">Поточний стан БД:</p>
      <table style="max-width:420px"><tbody>${Object.entries(stats).map(([t, c]) =>
        `<tr><td>${TABLE_LABELS[t] || t}</td><td style="text-align:right"><b>${c}</b></td></tr>`).join('')}
        <tr><td><b>Усього записів</b></td><td style="text-align:right"><b>${total}</b></td></tr></tbody></table>
      <div class="toolbar" style="margin-top:12px">
        <a class="btn" href="${withToken('/api/export/db')}">Зберегти резервну копію (.json)</a>
      </div>
      <p class="muted">Файл <code>pub-accounting-backup.json</code> містить усі дані. Зберігайте його для перенесення на інший компʼютер або відновлення.</p>
    </div>
    <div class="card"><h2>Відновлення з резервної копії</h2>
      <p class="muted" style="color:var(--danger)">Увага: відновлення ПОВНІСТЮ замінює поточні дані на дані з файлу.</p>
      <div class="toolbar">
        <input type="file" id="bk-file" accept="application/json,.json" />
        <button class="btn danger" id="bk-restore">Відновити з файлу</button>
      </div>
      <div id="bk-msg" class="muted" style="margin-top:8px"></div>
    </div>`;
  const msg = root.querySelector('#bk-msg');
  root.querySelector('#bk-restore').onclick = async () => {
    const f = root.querySelector('#bk-file').files[0];
    if (!f) { msg.textContent = 'Оберіть файл резервної копії.'; return; }
    if (!confirm('Відновлення замінить ВСІ поточні дані. Продовжити?')) return;
    msg.textContent = 'Відновлення...';
    try {
      const text = await f.text();
      const json = JSON.parse(text);
      const res = await api('POST', '/import/db', json);
      msg.style.color = 'var(--ok)';
      msg.textContent = `Відновлено. Таблиць: ${res.restored_tables.length}, записів: ${res.inserted}.`;
      await refreshSummary();
      setTimeout(() => renderBackup(), 1200);
    } catch (e) {
      msg.style.color = 'var(--danger)';
      msg.textContent = 'Помилка: ' + e.message;
    }
  };
}

// ---------- ДОВІДНИКИ (з редагуванням) ----------
const dictEdit = { org: null, venue: null, sp: null };
async function renderDictionaries() {
  await load();
  const root = document.getElementById('tab-dictionaries');
  root.innerHTML = '';

  const eo = dictEdit.org ? cache.orgs.find(o => o.id == dictEdit.org) : null;
  const orgs = el(`<div class="card"><h2>Організації</h2>
    <details class="inner-form"${eo ? ' open' : ''}><summary>${eo ? 'Редагування #' + eo.id : '+ Додати організацію'}</summary>
    <div class="toolbar" style="margin-top:8px">
      <label>Назва<input id="o-name" /></label>
      <label>Тип<select id="o-type">${opt(META.org_types, eo?.type)}</select></label>
      <label>Країна<input id="o-country" /></label>
      <button class="btn ${eo ? '' : 'sec'}" id="o-add" style="align-self:flex-end">${eo ? 'Зберегти' : 'Додати'}</button>
      ${eo ? '<button class="btn sec" id="o-cancel" style="align-self:flex-end">Скасувати</button>' : ''}
    </div></details>
    <table><tbody>${cache.orgs.map(o => `<tr><td>${esc(o.name)}</td><td>${META.org_types[o.type] || o.type}</td><td>${esc(o.country || '')}</td>
      <td style="white-space:nowrap"><button class="btn sec" data-edit="${o.id}">Ред.</button> <button class="btn danger" data-del="${o.id}">x</button></td></tr>`).join('')}</tbody></table></div>`);
  if (eo) { orgs.querySelector('#o-name').value = eo.name; orgs.querySelector('#o-country').value = eo.country || ''; orgs.querySelector('#o-cancel').onclick = () => { dictEdit.org = null; renderDictionaries(); }; }
  orgs.querySelector('#o-add').onclick = async () => {
    const body = { name: orgs.querySelector('#o-name').value, type: orgs.querySelector('#o-type').value, country: orgs.querySelector('#o-country').value || null };
    if (!body.name) return;
    if (eo) await api('PUT', '/organizations/' + eo.id, body); else await api('POST', '/organizations', body);
    dictEdit.org = null; renderDictionaries();
  };
  orgs.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { dictEdit.org = b.dataset.edit; renderDictionaries(); });
  orgs.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { await api('DELETE', '/organizations/' + b.dataset.del); renderDictionaries(); });
  addRowSearch(orgs, { placeholder: 'назва, тип, країна...' });

  const ev = dictEdit.venue ? cache.venues.find(v => v.id == dictEdit.venue) : null;
  const venues = el(`<div class="card"><h2>Видання / конференції</h2>
    <details class="inner-form"${ev ? ' open' : ''}><summary>${ev ? 'Редагування #' + ev.id : '+ Додати видання / конференцію'}</summary>
    <div class="toolbar" style="margin-top:8px">
      <label>Назва<input id="v-name" /></label>
      <label>Тип<select id="v-kind">${opt(META.venue_kinds, ev?.kind)}</select></label>
      <label>Спеціальність<select id="v-sp"><option value="">—</option>${cache.specialties.map(s => `<option value="${s.id}"${ev?.specialty_id == s.id ? ' selected' : ''}>${esc(s.code)} ${esc(s.name)}</option>`).join('')}</select></label>
      <label>Індексація<select id="v-idx">${opt(META.indexation, ev?.indexation)}</select></label>
      <label>Країна<input id="v-country" /></label>
      <button class="btn ${ev ? '' : 'sec'}" id="v-add" style="align-self:flex-end">${ev ? 'Зберегти' : 'Додати'}</button>
      ${ev ? '<button class="btn sec" id="v-cancel" style="align-self:flex-end">Скасувати</button>' : ''}
    </div></details>
    <table><tbody>${cache.venues.map(v => `<tr><td>${esc(v.name)}</td><td>${META.venue_kinds[v.kind] || v.kind}</td><td>${esc(v.specialty_code || '')}</td><td>${META.indexation[v.indexation] || v.indexation}</td><td>${esc(v.country || '')}</td>
      <td style="white-space:nowrap"><button class="btn sec" data-edit="${v.id}">Ред.</button> <button class="btn danger" data-del="${v.id}">x</button></td></tr>`).join('')}</tbody></table></div>`);
  if (ev) { venues.querySelector('#v-name').value = ev.name; venues.querySelector('#v-country').value = ev.country || ''; venues.querySelector('#v-cancel').onclick = () => { dictEdit.venue = null; renderDictionaries(); }; }
  venues.querySelector('#v-add').onclick = async () => {
    const body = {
      name: venues.querySelector('#v-name').value, kind: venues.querySelector('#v-kind').value,
      specialty_id: venues.querySelector('#v-sp').value ? +venues.querySelector('#v-sp').value : null,
      indexation: venues.querySelector('#v-idx').value, country: venues.querySelector('#v-country').value || null,
    };
    if (!body.name) return;
    if (ev) await api('PUT', '/venues/' + ev.id, body); else await api('POST', '/venues', body);
    dictEdit.venue = null; renderDictionaries();
  };
  venues.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { dictEdit.venue = b.dataset.edit; renderDictionaries(); });
  venues.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { await api('DELETE', '/venues/' + b.dataset.del); renderDictionaries(); });
  addRowSearch(venues, { placeholder: 'назва, спеціальність, індексація, країна...' });

  const es = dictEdit.sp ? cache.specialties.find(s => s.id == dictEdit.sp) : null;
  const sp = el(`<div class="card"><h2>Спеціальності / галузі</h2>
    <details class="inner-form"${es ? ' open' : ''}><summary>${es ? 'Редагування #' + es.id : '+ Додати спеціальність'}</summary>
    <div class="toolbar" style="margin-top:8px">
      <label>Код<input id="s-code" placeholder="Ф2" style="min-width:70px" /></label>
      <label>Назва<input id="s-name" /></label>
      <button class="btn ${es ? '' : 'sec'}" id="s-add" style="align-self:flex-end">${es ? 'Зберегти' : 'Додати'}</button>
      ${es ? '<button class="btn sec" id="s-cancel" style="align-self:flex-end">Скасувати</button>' : ''}
    </div></details>
    <table><tbody>${cache.specialties.map(s => `<tr><td><b>${esc(s.code)}</b></td><td>${esc(s.name)}</td>
      <td style="white-space:nowrap"><button class="btn sec" data-edit="${s.id}">Ред.</button> <button class="btn danger" data-del="${s.id}">x</button></td></tr>`).join('')}</tbody></table></div>`);
  if (es) { sp.querySelector('#s-code').value = es.code; sp.querySelector('#s-name').value = es.name; sp.querySelector('#s-cancel').onclick = () => { dictEdit.sp = null; renderDictionaries(); }; }
  sp.querySelector('#s-add').onclick = async () => {
    const body = { code: sp.querySelector('#s-code').value, name: sp.querySelector('#s-name').value };
    if (!body.code || !body.name) return;
    if (es) await api('PUT', '/specialties/' + es.id, body); else await api('POST', '/specialties', body);
    dictEdit.sp = null; renderDictionaries();
  };
  sp.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { dictEdit.sp = b.dataset.edit; renderDictionaries(); });
  sp.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { await api('DELETE', '/specialties/' + b.dataset.del); renderDictionaries(); });
  addRowSearch(sp, { placeholder: 'код, назва...' });

  root.append(orgs, venues, sp);
}

// ---------- КОРИСТУВАЧІ (адмін-вкладка, лише supervisor) ----------
let ROLE_LABELS = {};
async function renderUsers(editId = null) {
  const root = document.getElementById('tab-users');
  if (!can.admin()) { root.innerHTML = '<div class="card"><p class="muted">Доступ лише для адміністратора.</p></div>'; return; }
  const [users, roles] = await Promise.all([api('GET', '/users'), api('GET', '/roles')]);
  ROLE_LABELS = roles;
  const editing = editId ? users.find(u => u.id == editId) : null;
  root.innerHTML = '';

  const form = el(`<div class="card"><h2>${editing ? 'Редагування користувача: ' + esc(editing.username) : 'Новий користувач'}</h2>
    <div class="row">
      ${editing ? '' : '<label>Логін<input id="u-name" /></label>'}
      <label>Повне імʼя<input id="u-full" value="${esc(editing?.full_name || '')}" /></label>
      <label>Роль<select id="u-role">${opt(roles, editing?.role || 'read')}</select></label>
      <label>${editing ? 'Новий пароль (порожньо — без зміни)' : 'Пароль'}<input id="u-pass" type="password" /></label>
      ${editing ? `<label class="inline">Активний <input type="checkbox" id="u-active"${editing.active ? ' checked' : ''}/></label>` : ''}
      <button class="btn" id="u-save" style="align-self:flex-end">${editing ? 'Зберегти' : 'Створити'}</button>
      ${editing ? '<button class="btn sec" id="u-cancel" style="align-self:flex-end">Скасувати</button>' : ''}
    </div>
    <p class="muted">Ролі: <b>Тільки читання</b> — лише перегляд; <b>Читання/запис</b> — редагування даних, без вкладок «Користувачі» та «БД (резерв)»; <b>Адміністратор</b> — повні права.</p>
  </div>`);
  if (editing) form.querySelector('#u-cancel').onclick = () => renderUsers();
  form.querySelector('#u-save').onclick = async () => {
    const g = (id) => { const e = form.querySelector(id); return e ? e.value : undefined; };
    try {
      if (editing) {
        const body = { full_name: g('#u-full') || null, role: g('#u-role'), active: form.querySelector('#u-active').checked };
        if (g('#u-pass')) body.password = g('#u-pass');
        await api('PUT', '/users/' + editing.id, body);
      } else {
        if (!g('#u-name') || !g('#u-pass')) return alert('Вкажіть логін і пароль');
        await api('POST', '/users', { username: g('#u-name'), password: g('#u-pass'), role: g('#u-role'), full_name: g('#u-full') || null });
      }
      renderUsers();
    } catch (e) { alert('Помилка: ' + e.message); }
  };

  const list = el(`<div class="card"><h2>Користувачі (${users.length})</h2>
    <table><thead><tr><th>Логін</th><th>Повне імʼя</th><th>Роль</th><th>Активний</th><th>Створено</th><th></th></tr></thead>
    <tbody>${users.map(u => `<tr>
      <td><b>${esc(u.username)}</b>${u.username === currentUser.username ? ' <span class="tag stud">це ви</span>' : ''}</td>
      <td>${esc(u.full_name || '')}</td>
      <td>${esc(roles[u.role] || u.role)}</td>
      <td>${u.active ? 'так' : '<span class="muted">ні</span>'}</td>
      <td class="muted">${esc(u.created_at || '')}</td>
      <td style="white-space:nowrap"><button class="btn sec" data-edit="${u.id}">Ред.</button> <button class="btn danger" data-del="${u.id}"${u.username === currentUser.username ? ' disabled title="Не можна видалити себе"' : ''}>x</button></td>
    </tr>`).join('')}</tbody></table></div>`);
  list.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { renderUsers(b.dataset.edit); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  list.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
    if (b.disabled) return;
    if (confirm('Видалити користувача?')) { try { await api('DELETE', '/users/' + b.dataset.del); renderUsers(); } catch (e) { alert('Помилка: ' + e.message); } }
  });
  addRowSearch(list, { placeholder: 'логін, імʼя, роль...' });
  root.append(form, list);
}
TABS.users = () => renderUsers();

// ---------- застосування ролей до UI ----------
function applyRolesToUI() {
  // вкладки, доступні лише адміністратору
  const adminTabs = ['backup', 'users'];
  document.querySelectorAll('.tabs button').forEach(b => {
    const t = b.dataset.tab;
    b.style.display = (adminTabs.includes(t) && !can.admin()) ? 'none' : '';
  });
  // режим «лише читання» — ховаємо кнопки дій (додати/ред./видалити) через CSS-клас на body
  document.body.classList.toggle('readonly', currentUser && currentUser.role === 'read');
}

// ---------- userbar / логін / логаут ----------
function renderUserbar() {
  const bar = document.getElementById('userbar');
  if (!bar || !currentUser) return;
  bar.innerHTML = `<span class="u-name">${esc(currentUser.full_name || currentUser.username)}</span>
    <span class="u-role">${esc(ROLE_LABELS[currentUser.role] || currentUser.role)}</span>
    <button class="btn sec" id="btn-logout">Вихід</button>`;
  bar.querySelector('#btn-logout').onclick = doLogout;
}
async function doLogout() {
  try { await api('POST', '/logout'); } catch {}
  authToken = null; currentUser = null; localStorage.removeItem('pa_token');
  showLogin();
}
function handleSessionExpired() {
  authToken = null; currentUser = null; localStorage.removeItem('pa_token');
  showLogin('Сесія завершилася. Увійдіть знову.');
}
function showLogin(msg) {
  document.getElementById('app-root').classList.add('hidden');
  const scr = document.getElementById('login-screen');
  scr.classList.remove('hidden');
  document.getElementById('login-error').textContent = msg || '';
  document.getElementById('login-user').focus();
}
async function startApp() {
  // Спочатку завантажуємо ВСІ потрібні дані; перемикаємо екрани лише коли все готове.
  ROLE_LABELS = await api('GET', '/roles');
  META = await api('GET', '/meta');
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('app-root').classList.remove('hidden');
  applyRolesToUI();
  renderUserbar();
  await refreshSummary();
  const wanted = new URLSearchParams(location.search).get('tab');
  try {
    switchTab(TABS[wanted] && !(['backup', 'users'].includes(wanted) && !can.admin()) ? wanted : 'publications');
  } catch (e) {
    const b = document.getElementById('js-error-banner');
    if (b) { b.style.display = 'block'; b.textContent = 'Помилка відображення вкладки: ' + (e.message || e); }
  }
}

// ---------- старт ----------
const loginForm = document.getElementById('login-form');
if (!loginForm) {
  // Старий index.html у кеші браузера (без екрана логіну) — поясни користувачу.
  alert('Виявлено застарілу версію сторінки в кеші браузера.\n\nНатисніть Ctrl+Shift+R (жорстке оновлення), щоб завантажити актуальну версію застосунку.');
} else {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('login-user').value.trim();
    const password = document.getElementById('login-pass').value;
    document.getElementById('login-error').textContent = 'Вхід...';
    try {
      const res = await api('POST', '/login', { username, password });
      authToken = res.token; currentUser = res.user; localStorage.setItem('pa_token', authToken);
      document.getElementById('login-pass').value = '';
      await startApp();
      document.getElementById('login-error').textContent = '';
    } catch (err) {
      // якщо вхід пройшов, але startApp впав — повертаємо екран логіну з видимою помилкою
      document.getElementById('app-root').classList.add('hidden');
      document.getElementById('login-screen').classList.remove('hidden');
      document.getElementById('login-error').textContent = err.message || 'Помилка входу';
    }
  });

  (async () => {
    if (authToken) {
      try { const me = await api('GET', '/me'); currentUser = me.user; await startApp(); return; }
      catch { authToken = null; localStorage.removeItem('pa_token'); }
    }
    showLogin();
  })();
}
