// БД на вбудованому node:sqlite (без нативних залежностей).
import { fileURLToPath } from 'node:url';
import path from 'node:path';

// Вбудована БД node:sqlite потребує Node.js >= 22.5 (у 22.5–22.12 — з прапорцем
// --experimental-sqlite, який додає start.bat). Якщо модуль недоступний — зрозуміла помилка.
let DatabaseSync;
try {
  ({ DatabaseSync } = await import('node:sqlite'));
} catch (e) {
  console.error('\n[ПОМИЛКА] Не вдалося завантажити вбудовану базу node:sqlite.');
  console.error('  Поточна версія Node.js:', process.version);
  console.error('  Потрібен Node.js >= 22.5 (рекомендовано 24 LTS): https://nodejs.org/');
  console.error('  Деталі:', e.message, '\n');
  process.exit(1);
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const DB_PATH = path.join(__dirname, '..', 'data.sqlite');

export const db = new DatabaseSync(DB_PATH);

db.exec(`
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS organizations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'external',   -- our_dept|our_univ|external|foreign
  country TEXT
);

CREATE TABLE IF NOT EXISTS specialties (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS venues (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'conference', -- journal|conference
  country TEXT,
  specialty_id INTEGER REFERENCES specialties(id) ON DELETE SET NULL,
  indexation TEXT NOT NULL DEFAULT 'none'  -- none|scopus|wos|scopus_wos
);

CREATE TABLE IF NOT EXISTS authors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name_uk TEXT NOT NULL,
  full_name_en TEXT,
  role TEXT NOT NULL DEFAULT 'teacher',     -- teacher|student|master|phd|pupil
  birth_year INTEGER,
  organization_id INTEGER REFERENCES organizations(id) ON DELETE SET NULL,
  is_foreign INTEGER NOT NULL DEFAULT 0,
  academic_title TEXT
);

CREATE TABLE IF NOT EXISTS publications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'article',     -- article|theses|report
  category TEXT,                            -- article_ua|article_foreign|conf_ua|conf_foreign|prep_foreign|monograph|textbook
  venue_id INTEGER REFERENCES venues(id) ON DELETE SET NULL,
  year INTEGER,
  pub_date TEXT,
  place TEXT,
  page_from INTEGER,
  page_to INTEGER,
  doi TEXT,
  url TEXT,
  language TEXT DEFAULT 'uk',               -- uk|en|de
  scopus INTEGER NOT NULL DEFAULT 0,
  wos INTEGER NOT NULL DEFAULT 0,
  is_professional INTEGER NOT NULL DEFAULT 0, -- фахове видання
  impact_factor INTEGER NOT NULL DEFAULT 0,   -- має імпакт-фактор
  gryf_mon INTEGER NOT NULL DEFAULT 0,        -- з грифом МОН (підручники)
  scimetric_base TEXT,                        -- наукометрична база (індекс цитування, ІФ)
  volume_issue TEXT,                          -- том, номер (випуск)
  citations INTEGER NOT NULL DEFAULT 0,       -- к-сть цитувань
  keywords TEXT,
  abstract TEXT
);

CREATE TABLE IF NOT EXISTS publication_authors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  publication_id INTEGER NOT NULL REFERENCES publications(id) ON DELETE CASCADE,
  author_id INTEGER NOT NULL REFERENCES authors(id) ON DELETE CASCADE,
  ord INTEGER NOT NULL DEFAULT 1,
  role_in_pub TEXT NOT NULL DEFAULT 'author', -- author|advisor|coauthor
  is_student INTEGER NOT NULL DEFAULT 0,
  presented INTEGER NOT NULL DEFAULT 0        -- особисто брав участь у заході (для конференцій)
);

CREATE TABLE IF NOT EXISTS name_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author_id INTEGER NOT NULL REFERENCES authors(id) ON DELETE CASCADE,
  old_name TEXT NOT NULL,
  new_name TEXT NOT NULL,
  changed_on TEXT
);

-- VIII. Виставки
CREATE TABLE IF NOT EXISTS exhibitions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  developers TEXT,            -- ПІБ розроблювачів експонату
  exhibit_name TEXT NOT NULL, -- назва експонату
  exhibition_name TEXT,       -- назва виставки
  date_place TEXT,            -- дата й місце проведення
  awards TEXT,                -- нагороди
  year INTEGER
);

-- IX. Патенти / охоронні документи
CREATE TABLE IF NOT EXISTS patents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  count INTEGER NOT NULL DEFAULT 1, -- кількість патентів
  theme_no TEXT,                    -- № теми / реєстраційні дані
  kind TEXT DEFAULT 'applied',      -- fundamental|applied
  supervisor TEXT,                  -- ПІБ наукового керівника теми
  title TEXT,                       -- назва (для авт. свідоцтв / опис)
  year INTEGER
);

-- Розробки, впроваджені за межами університету
CREATE TABLE IF NOT EXISTS developments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_authors TEXT NOT NULL, -- назва та автори розробки
  indicators TEXT,             -- важливі показники / переваги / ефект
  place TEXT,                  -- місце впровадження
  act_date TEXT,               -- дата акту впровадження
  results TEXT,                -- практичні результати
  framework TEXT,              -- у рамках (тема №, госпдоговір тощо)
  year INTEGER
);
`);

// --- Легка міграція: додати відсутні колонки в наявну БД (без втрати даних) ---
function ensureColumn(table, col, decl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((r) => r.name);
  if (!cols.includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${decl}`);
}
ensureColumn('publications', 'category', 'category TEXT');
ensureColumn('publications', 'is_professional', 'is_professional INTEGER NOT NULL DEFAULT 0');
ensureColumn('publications', 'impact_factor', 'impact_factor INTEGER NOT NULL DEFAULT 0');
ensureColumn('publications', 'gryf_mon', 'gryf_mon INTEGER NOT NULL DEFAULT 0');
ensureColumn('publications', 'scimetric_base', 'scimetric_base TEXT');
ensureColumn('publications', 'volume_issue', 'volume_issue TEXT');
ensureColumn('publications', 'citations', 'citations INTEGER NOT NULL DEFAULT 0');
ensureColumn('publications', 'keywords', 'keywords TEXT');
ensureColumn('publication_authors', 'presented', 'presented INTEGER NOT NULL DEFAULT 0');
ensureColumn('authors', 'orcid', 'orcid TEXT');
ensureColumn('authors', 'scopus_id', 'scopus_id TEXT');
ensureColumn('authors', 'researcher_id', 'researcher_id TEXT');
ensureColumn('authors', 'google_scholar', 'google_scholar TEXT');

seedIfEmpty();

function seedIfEmpty() {
  const n = db.prepare('SELECT COUNT(*) AS c FROM publications').get().c;
  if (n > 0) return;

  const insOrg = db.prepare('INSERT INTO organizations(name,type,country) VALUES(?,?,?)');
  const org = {
    hnure: insOrg.run('ХНУРЕ (Харківський нац. ун-т радіоелектроніки)', 'our_univ', 'Україна').lastInsertRowid,
    dept: insOrg.run('Кафедра програмної інженерії, ХНУРЕ', 'our_dept', 'Україна').lastInsertRowid,
    vntu: insOrg.run('Вінницький національний технічний університет', 'external', 'Україна').lastInsertRowid,
    karazin: insOrg.run('ХНУ імені В.Н. Каразіна', 'external', 'Україна').lastInsertRowid,
    deu: insOrg.run('Університет (Німеччина)', 'foreign', 'Німеччина').lastInsertRowid,
    usa: insOrg.run('IT-компанія (США)', 'foreign', 'США').lastInsertRowid,
    pl: insOrg.run('Politechnika Warszawska', 'foreign', 'Польща').lastInsertRowid,
    odesa: insOrg.run('Одеський політехнічний національний університет', 'external', 'Україна').lastInsertRowid,
    lviv: insOrg.run('Національний університет «Львівська політехніка»', 'external', 'Україна').lastInsertRowid,
  };

  const insSp = db.prepare('INSERT INTO specialties(code,name) VALUES(?,?)');
  const sp = {
    f1: insSp.run('Ф1', 'Інформаційні технології').lastInsertRowid,
    f2: insSp.run('Ф2', 'Програмна інженерія').lastInsertRowid,
    f3: insSp.run('Ф3', "Комп'ютерні науки").lastInsertRowid,
  };

  const insV = db.prepare('INSERT INTO venues(name,kind,country,specialty_id,indexation) VALUES(?,?,?,?,?)');
  const v = {
    // конференції
    khpi: insV.run('IEEE KhPI Week on Advanced Technology (KhPIWeek)', 'conference', 'Україна', sp.f3, 'scopus').lastInsertRowid,
    profit: insV.run('ProfIT AI Workshop (CEUR Workshop Proceedings)', 'conference', 'Велика Британія', sp.f2, 'none').lastInsertRowid,
    dessert: insV.run('IEEE DESSERT', 'conference', 'Греція', sp.f3, 'scopus').lastInsertRowid,
    sshi: insV.run('Сучасні інформаційні технології та системи штучного інтелекту', 'conference', 'Україна', sp.f2, 'none').lastInsertRowid,
    softtech: insV.run('SoftTech: Software Engineering and Advanced Information Technologies', 'conference', 'Україна', sp.f2, 'none').lastInsertRowid,
    iust: insV.run('Інформаційні управляючі системи та технології (ІУСТ-Одеса)', 'conference', 'Україна', sp.f1, 'scopus').lastInsertRowid,
    kism: insV.run("Комп'ютерні інтелектуальні системи та мережі (КІСМ)", 'conference', 'Україна', sp.f3, 'none').lastInsertRowid,
    csit: insV.run('IEEE CSIT: Computer Science and Information Technologies', 'conference', 'Україна', sp.f3, 'scopus').lastInsertRowid,
    // журнали
    bionica: insV.run('Біоніка інтелекту', 'journal', 'Україна', sp.f3, 'scopus').lastInsertRowid,
    naukpraci: insV.run('Наукові праці ВНТУ', 'journal', 'Україна', sp.f1, 'none').lastInsertRowid,
    itssi: insV.run('Innovative Technologies and Scientific Solutions for Industries', 'journal', 'Україна', sp.f3, 'scopus').lastInsertRowid,
    riu: insV.run('Радіоелектроніка, інформатика, управління', 'journal', 'Україна', sp.f2, 'wos').lastInsertRowid,
    cejet: insV.run('Eastern-European Journal of Enterprise Technologies', 'journal', 'Україна', sp.f1, 'scopus').lastInsertRowid,
    ujit: insV.run('Український журнал інформаційних технологій', 'journal', 'Україна', sp.f1, 'none').lastInsertRowid,
    kit: insV.run("Комп'ютерно-інтегровані технології: освіта, наука, виробництво", 'journal', 'Україна', sp.f1, 'none').lastInsertRowid,
  };

  const insA = db.prepare('INSERT INTO authors(full_name_uk,full_name_en,role,birth_year,organization_id,is_foreign,academic_title,orcid,scopus_id,google_scholar) VALUES(?,?,?,?,?,?,?,?,?,?)');
  const a = {
    kobziev: insA.run('Кобзєв В.Г.', 'Volodymyr Kobziev', 'teacher', 1975, org.dept, 0, 'доцент, к.т.н.', '0000-0002-1111-2222', '57210000001', 'kobziev_gs').lastInsertRowid,
    khovrat: insA.run('Ховрат А.В.', 'Artem Khovrat', 'phd', 2000, org.dept, 0, null, '0000-0003-3333-4444', '58110000002', null).lastInsertRowid,
    luchenko: insA.run('Лученко Я.В.', 'Ya. Luchenko', 'phd', 2000, org.dept, 0, null, null, null, null).lastInsertRowid,
    gotsuliak: insA.run('Гоцуляк К.О.', 'K. Hotsuliak', 'student', 2004, org.dept, 0, null, null, null, null).lastInsertRowid,
    golovashenko: insA.run('Головашенко І.В.', 'I. Holovashenko', 'master', 2002, org.dept, 0, null, null, null, null).lastInsertRowid,
    taverdiiev: insA.run('Тавердієв Д.Д.', 'D. Taverdiiev', 'student', 2004, org.dept, 0, null, null, null, null).lastInsertRowid,
    tarasenko: insA.run('Тарасенко А.В.', 'A. Tarasenko', 'student', 2004, org.dept, 0, null, null, null, null).lastInsertRowid,
    strelchenko: insA.run('Стрельченко А.', 'Andrii Strelchenko', 'student', 2003, org.dept, 0, null, null, null, null).lastInsertRowid,
    shyrokopetleva: insA.run('Широкопетлєва М.С.', 'M. Shyrokopetleva', 'teacher', 1985, org.dept, 0, 'ст. викладач', null, null, null).lastInsertRowid,
    shtanko: insA.run('Штанько В.І.', 'V. Shtanko', 'teacher', 1970, org.dept, 0, 'доцент', null, null, null).lastInsertRowid,
    strukov: insA.run('Струков В.М.', 'Volodymyr Strukov', 'teacher', 1985, org.karazin, 0, 'доцент', null, null, null).lastInsertRowid,
    schunm: insA.run('Шунм Є.', 'Evgeni Schunm', 'teacher', 1980, org.deu, 1, null, null, null, null).lastInsertRowid,
    yakovlev: insA.run('Яковлев С.', 'Sergiy Yakovlev', 'teacher', 1960, org.usa, 1, 'професор', null, null, null).lastInsertRowid,
    shubin: insA.run('Шубін І.Ю.', 'I. Shubin', 'teacher', 1972, org.dept, 0, 'доцент', null, null, null).lastInsertRowid,
    gruzdo: insA.run('Груздо І.В.', 'I. Hruzdo', 'teacher', 1986, org.dept, 0, 'доцент', null, null, null).lastInsertRowid,
    derkach: insA.run('Деркач А.С.', 'A. Derkach', 'student', 2003, org.dept, 0, null, null, null, null).lastInsertRowid,
    // додаткові викладачі кафедри
    yerokhin: insA.run('Єрохін А.Л.', 'A. Yerokhin', 'teacher', 1965, org.hnure, 0, 'професор, д.т.н.', '0000-0002-9001-0001', null, null).lastInsertRowid,
    bodianskyi: insA.run('Бодянський Є.В.', 'Ye. Bodianskyi', 'teacher', 1950, org.hnure, 0, 'професор, д.т.н.', '0000-0001-3434-0002', null, null).lastInsertRowid,
    smelyakov: insA.run('Смеляков К.С.', 'K. Smelyakov', 'teacher', 1978, org.dept, 0, 'професор, д.т.н.', null, null, null).lastInsertRowid,
    nosov: insA.run('Носов П.С.', 'P. Nosov', 'teacher', 1980, org.vntu, 0, 'доцент', null, null, null).lastInsertRowid,
    // аспіранти / магістранти
    melnyk: insA.run('Мельник О.В.', 'O. Melnyk', 'phd', 1999, org.dept, 0, null, null, null, null).lastInsertRowid,
    bondarenko: insA.run('Бондаренко І.М.', 'I. Bondarenko', 'master', 2001, org.dept, 0, null, null, null, null).lastInsertRowid,
    kovalenko: insA.run('Коваленко Д.О.', 'D. Kovalenko', 'master', 2002, org.dept, 0, null, null, null, null).lastInsertRowid,
    // студенти
    petrenko: insA.run('Петренко А.С.', 'A. Petrenko', 'student', 2004, org.dept, 0, null, null, null, null).lastInsertRowid,
    sydorenko: insA.run('Сидоренко В.В.', 'V. Sydorenko', 'student', 2005, org.dept, 0, null, null, null, null).lastInsertRowid,
    moroz: insA.run('Мороз К.І.', 'K. Moroz', 'student', 2004, org.dept, 0, null, null, null, null).lastInsertRowid,
    tkachenko: insA.run('Ткаченко О.П.', 'O. Tkachenko', 'student', 2005, org.dept, 0, null, null, null, null).lastInsertRowid,
    lysenko: insA.run('Лисенко М.А.', 'M. Lysenko', 'student', 2003, org.dept, 0, null, null, null, null).lastInsertRowid,
    pupil1: insA.run('Іваненко С. (ліцей)', 'S. Ivanenko', 'pupil', 2008, org.dept, 0, null, null, null, null).lastInsertRowid,
    // іноземні співавтори
    mueller: insA.run('Мюллер Г.', 'Hans Mueller', 'teacher', 1975, org.deu, 1, 'professor', null, null, null).lastInsertRowid,
    novak: insA.run('Новак П.', 'Petr Novak', 'teacher', 1982, org.pl, 1, null, null, null, null).lastInsertRowid,
  };

  const insP = db.prepare(`INSERT INTO publications
    (title,type,category,venue_id,year,pub_date,place,page_from,page_to,doi,url,language,
     scopus,wos,is_professional,impact_factor,gryf_mon,scimetric_base,volume_issue,citations,keywords,abstract)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const insPA = db.prepare('INSERT INTO publication_authors(publication_id,author_id,ord,role_in_pub,is_student,presented) VALUES(?,?,?,?,?,?)');
  const addPub = (p, authors) => {
    const id = insP.run(
      p.title, p.type ?? 'article', p.category ?? null, p.venue_id ?? null, p.year ?? null, p.pub_date ?? null, p.place ?? null,
      p.page_from ?? null, p.page_to ?? null, p.doi ?? null, p.url ?? null, p.language ?? 'uk',
      p.scopus ? 1 : 0, p.wos ? 1 : 0, p.is_professional ? 1 : 0, p.impact_factor ? 1 : 0, p.gryf_mon ? 1 : 0,
      p.scimetric_base ?? null, p.volume_issue ?? null, p.citations ?? 0, p.keywords ?? null, p.abstract ?? null
    ).lastInsertRowid;
    authors.forEach((au, i) => insPA.run(id, au.id, i + 1, au.role ?? 'author', au.student ? 1 : 0, au.presented ? 1 : 0));
    return id;
  };

  // I. Стаття в періодичному виданні України (фахове)
  addPub({ title: 'Штучний інтелект та зображення: підробка, доповнення, чи реальність?',
    type: 'article', category: 'article_ua', venue_id: v.naukpraci, year: 2024, place: 'Вінниця',
    page_from: 17, page_to: 24, doi: '10.31649/2307-5376-2024-3-17-24', language: 'uk',
    is_professional: 1, volume_issue: 'вип. 3, 2024', scimetric_base: 'фахове (кат. Б)',
    keywords: 'штучний інтелект; обробка зображень; підробка' },
    [{ id: a.gotsuliak, student: 1 }, { id: a.shyrokopetleva }, { id: a.shtanko }]);

  // II / III.1 (Scopus) — стаття у фаховому журналі категорії А, Scopus
  addPub({ title: 'A TWO-LAYER MODEL TO DETECTING FALSIFIED INFORMATION USING NEURAL NETWORKS IN SOCIALLY ORIENTED SYSTEMS',
    type: 'article', category: 'article_foreign', venue_id: v.itssi, year: 2025, place: 'Харків',
    page_from: 112, page_to: 123, doi: '10.30837/2522-9818.2025.4.112', language: 'en',
    scopus: 1, is_professional: 1, impact_factor: 1, scimetric_base: 'Scopus', volume_issue: 'No. 4 (34)',
    citations: 1, keywords: 'data analysis; naive Bayes classifier; neural networks; parallelization; fake news' },
    [{ id: a.khovrat, student: 1 }, { id: a.kobziev }]);

  // III.1 (Scopus, конференція IEEE)
  addPub({ title: 'Audio Forgery Detection via Combined Recurrent-Convolutional Neural Network Architecture',
    type: 'report', category: 'conf_foreign', venue_id: v.khpi, year: 2025, place: 'Kharkiv, Ukraine',
    page_from: 1, page_to: 4, doi: '10.1109/KhPIWeek61436.2025.11288649', language: 'en',
    scopus: 1, impact_factor: 1, scimetric_base: 'Scopus', volume_issue: '6th KhPIWeek' },
    [{ id: a.khovrat, student: 1, presented: 1 }, { id: a.kobziev }]);

  // IV. Конференція за кордоном з іноземним співавтором (Scopus)
  addPub({ title: 'Implementation Specifics of Lock-Free Containers for High Loaded Multithreaded Applications',
    type: 'report', category: 'conf_foreign', venue_id: v.dessert, year: 2024, place: 'Athens, Greece',
    page_from: 1, page_to: 5, doi: '10.1109/DESSERT63402.2024.11122219', language: 'en',
    scopus: 1, impact_factor: 1, scimetric_base: 'Scopus' },
    [{ id: a.khovrat, student: 1, presented: 1 }, { id: a.strelchenko, student: 1 }, { id: a.kobziev }, { id: a.yakovlev, role: 'coauthor' }]);

  // II. Стаття за кордоном з іноземним співавтором
  addPub({ title: 'AI-Facilitated Software Project Generation from Natural Language Using Curated Code Snippets',
    type: 'article', category: 'article_foreign', venue_id: v.profit, year: 2025, place: 'Liverpool, UK',
    page_from: 188, page_to: 197, language: 'en', impact_factor: 1, scimetric_base: 'CEUR-WS',
    keywords: 'code generation; natural language; curated snippets' },
    [{ id: a.khovrat, student: 1 }, { id: a.strukov }, { id: a.schunm, role: 'coauthor' }, { id: a.kobziev }]);

  // III. Конференція по Україні (тези)
  addPub({ title: 'Емпіричний аналіз апаратного масштабування фреймворків MapReduce та Apache Spark для ітеративних алгоритмів покриття',
    type: 'theses', category: 'conf_ua', venue_id: v.sshi, year: 2026, place: 'Харків-Яремче, 27-29 квітня 2026',
    page_from: 198, page_to: 199, language: 'uk' },
    [{ id: a.luchenko, student: 1, presented: 1 }, { id: a.kobziev, role: 'advisor' }]);

  addPub({ title: 'Порівняльний аналіз мовних моделей штучного інтелекту для структуризації інформації у системах електронної комерції',
    type: 'theses', category: 'conf_ua', venue_id: v.sshi, year: 2026, place: 'Харків-Яремче, 27-29 квітня 2026',
    page_from: 101, page_to: 102, language: 'uk' },
    [{ id: a.tarasenko, student: 1, presented: 1 }, { id: a.kobziev, role: 'advisor' }]);

  addPub({ title: 'Програмна система аналізу медичних зображень на основі методу опорних векторів',
    type: 'theses', category: 'conf_ua', venue_id: v.sshi, year: 2026, place: 'Харків-Яремче, 27-29 квітня 2026',
    page_from: 175, page_to: 178, language: 'uk' },
    [{ id: a.gotsuliak, student: 1, presented: 1 }, { id: a.golovashenko, student: 1 }, { id: a.kobziev, role: 'advisor' }]);

  // V. Підготовлено до друку за кордоном
  addPub({ title: 'Adaptive Forecasting for Time Series with Varying Seasonality (preprint)',
    type: 'article', category: 'prep_foreign', venue_id: v.profit, year: 2026, place: 'UK',
    page_from: 1, page_to: 12, language: 'en', impact_factor: 1, scimetric_base: 'submitted' },
    [{ id: a.schunm, role: 'coauthor' }, { id: a.kobziev }]);

  // VI. Монографія (розділ)
  addPub({ title: 'Методи штучного інтелекту в обробці медичних зображень (розділ колективної монографії)',
    type: 'article', category: 'monograph', venue_id: null, year: 2025, place: 'Харків, ХНУРЕ',
    page_from: 45, page_to: 78, language: 'uk', gryf_mon: 1 },
    [{ id: a.kobziev }, { id: a.shubin }, { id: a.gruzdo }]);

  // VII. Підручник / навчальний посібник
  addPub({ title: 'Мультимедіа системи',
    type: 'article', category: 'textbook', venue_id: null, year: 2023, place: 'Україна, Харків, ХНУРЕ',
    page_from: 1, page_to: 180, language: 'uk', gryf_mon: 1 },
    [{ id: a.shubin }, { id: a.gruzdo }, { id: a.strukov }]);

  // ---------- Додаткові публікації (для повноти набору) ----------
  // I. Статті в Україні (фахові)
  addPub({ title: 'Метод кластеризації потокових даних на основі нейронних мереж адаптивного резонансу',
    type: 'article', category: 'article_ua', venue_id: v.bionica, year: 2025, place: 'Харків',
    page_from: 34, page_to: 41, doi: '10.30837/bi.2025.1.05', language: 'uk', is_professional: 1,
    volume_issue: '№ 1 (84)', scimetric_base: 'Scopus', scopus: 1, citations: 2,
    keywords: 'кластеризація; потокові дані; ART; нейронні мережі' },
    [{ id: a.bodianskyi }, { id: a.melnyk, student: 1 }, { id: a.kobziev }]);

  addPub({ title: 'Архітектура мікросервісної системи моніторингу навчального процесу',
    type: 'article', category: 'article_ua', venue_id: v.ujit, year: 2025, place: 'Львів',
    page_from: 88, page_to: 96, language: 'uk', is_professional: 1, volume_issue: 'Т. 7, № 2',
    scimetric_base: 'фахове (кат. Б)', keywords: 'мікросервіси; моніторинг; REST API' },
    [{ id: a.gruzdo }, { id: a.bondarenko, student: 1 }, { id: a.kobziev }]);

  addPub({ title: 'Оцінювання якості програмного коду засобами статичного аналізу',
    type: 'article', category: 'article_ua', venue_id: v.kit, year: 2024, place: 'Луцьк',
    page_from: 102, page_to: 110, language: 'uk', is_professional: 1, volume_issue: '№ 3',
    scimetric_base: 'фахове (кат. Б)', keywords: 'якість коду; статичний аналіз; метрики' },
    [{ id: a.shubin }, { id: a.kovalenko, student: 1 }]);

  addPub({ title: 'Алгоритм виявлення аномалій у часових рядах телеметрії',
    type: 'article', category: 'article_ua', venue_id: v.naukpraci, year: 2025, place: 'Вінниця',
    page_from: 12, page_to: 20, language: 'uk', is_professional: 1, volume_issue: 'вип. 2, 2025',
    scimetric_base: 'фахове (кат. Б)', keywords: 'аномалії; часові ряди; телеметрія' },
    [{ id: a.nosov }, { id: a.petrenko, student: 1 }, { id: a.kobziev }]);

  // II. Статті за кордоном (Scopus/WoS)
  addPub({ title: 'Deep Learning Approach for Real-Time Object Detection in Industrial IoT',
    type: 'article', category: 'article_foreign', venue_id: v.cejet, year: 2025, place: 'Kharkiv',
    page_from: 6, page_to: 18, doi: '10.15587/1729-4061.2025.300001', language: 'en', scopus: 1,
    is_professional: 1, impact_factor: 1, scimetric_base: 'Scopus Q3', volume_issue: 'Vol. 3, No. 9 (129)',
    citations: 4, keywords: 'deep learning; object detection; industrial IoT' },
    [{ id: a.smelyakov }, { id: a.khovrat, student: 1 }, { id: a.mueller, role: 'coauthor' }, { id: a.kobziev }]);

  addPub({ title: 'A Hybrid Model for Software Defect Prediction Using Ensemble Methods',
    type: 'article', category: 'article_foreign', venue_id: v.riu, year: 2024, place: 'Zaporizhzhia',
    page_from: 45, page_to: 57, doi: '10.15588/1607-3274-2024-2-5', language: 'en', wos: 1,
    is_professional: 1, impact_factor: 1, scimetric_base: 'Web of Science', volume_issue: 'No. 2',
    citations: 3, keywords: 'defect prediction; ensemble; machine learning' },
    [{ id: a.gruzdo }, { id: a.novak, role: 'coauthor' }, { id: a.kobziev }]);

  // III. Конференції по Україні (тези)
  addPub({ title: 'Застосування трансформерів для класифікації наукових текстів',
    type: 'theses', category: 'conf_ua', venue_id: v.softtech, year: 2025, place: 'Київ, КПІ, травень 2025',
    page_from: 210, page_to: 212, language: 'uk' },
    [{ id: a.kovalenko, student: 1, presented: 1 }, { id: a.kobziev, role: 'advisor' }]);

  addPub({ title: 'Веб-застосунок для обліку успішності студентів на Node.js',
    type: 'theses', category: 'conf_ua', venue_id: v.kism, year: 2025, place: 'Харків, листопад 2025',
    page_from: 55, page_to: 57, language: 'uk' },
    [{ id: a.sydorenko, student: 1, presented: 1 }, { id: a.gruzdo, role: 'advisor' }]);

  addPub({ title: 'Порівняння алгоритмів стиснення зображень для мобільних застосунків',
    type: 'theses', category: 'conf_ua', venue_id: v.sshi, year: 2026, place: 'Харків-Яремче, квітень 2026',
    page_from: 320, page_to: 322, language: 'uk' },
    [{ id: a.moroz, student: 1, presented: 1 }, { id: a.shubin, role: 'advisor' }]);

  addPub({ title: 'Розробка чат-бота технічної підтримки із застосуванням LLM',
    type: 'theses', category: 'conf_ua', venue_id: v.iust, year: 2025, place: 'Одеса, вересень 2025',
    page_from: 144, page_to: 146, language: 'uk' },
    [{ id: a.tkachenko, student: 1, presented: 1 }, { id: a.lysenko, student: 1 }, { id: a.kobziev, role: 'advisor' }]);

  addPub({ title: 'Інтелектуальна система розпізнавання дорожніх знаків',
    type: 'theses', category: 'conf_ua', venue_id: v.kism, year: 2024, place: 'Харків, листопад 2024',
    page_from: 78, page_to: 80, language: 'uk' },
    [{ id: a.pupil1, student: 1, presented: 1 }, { id: a.melnyk }, { id: a.smelyakov, role: 'advisor' }]);

  // IV. Конференції за кордоном (Scopus, з іноземними співавторами)
  addPub({ title: 'Federated Learning for Privacy-Preserving Medical Image Analysis',
    type: 'report', category: 'conf_foreign', venue_id: v.csit, year: 2025, place: 'Lviv, Ukraine',
    page_from: 1, page_to: 6, doi: '10.1109/CSIT.2025.10000123', language: 'en', scopus: 1,
    impact_factor: 1, scimetric_base: 'Scopus', volume_issue: '20th CSIT' },
    [{ id: a.khovrat, student: 1, presented: 1 }, { id: a.mueller, role: 'coauthor' }, { id: a.kobziev }]);

  addPub({ title: 'Scalable Microservice Orchestration with Kubernetes for Research Data Platforms',
    type: 'report', category: 'conf_foreign', venue_id: v.dessert, year: 2025, place: 'Athens, Greece',
    page_from: 1, page_to: 7, doi: '10.1109/DESSERT.2025.10000456', language: 'en', scopus: 1,
    impact_factor: 1, scimetric_base: 'Scopus' },
    [{ id: a.bondarenko, student: 1, presented: 1 }, { id: a.novak, role: 'coauthor' }, { id: a.gruzdo }]);

  // V. Підготовлені до друку (закордон)
  addPub({ title: 'Explainable AI Methods for Software Quality Assessment (under review)',
    type: 'article', category: 'prep_foreign', venue_id: v.cejet, year: 2026, place: 'Ukraine',
    page_from: 1, page_to: 14, language: 'en', impact_factor: 1, scimetric_base: 'submitted (Scopus)' },
    [{ id: a.smelyakov }, { id: a.kovalenko, student: 1 }, { id: a.kobziev }]);

  // VI. Монографія
  addPub({ title: 'Інтелектуальний аналіз даних у програмній інженерії (монографія)',
    type: 'article', category: 'monograph', venue_id: null, year: 2024, place: 'Харків, ХНУРЕ',
    page_from: 1, page_to: 240, language: 'uk', gryf_mon: 1 },
    [{ id: a.yerokhin }, { id: a.bodianskyi }, { id: a.kobziev }]);

  // VII. Підручник
  addPub({ title: 'Основи програмної інженерії: навчальний посібник',
    type: 'article', category: 'textbook', venue_id: null, year: 2024, place: 'Україна, Харків, ХНУРЕ',
    page_from: 1, page_to: 312, language: 'uk', gryf_mon: 1 },
    [{ id: a.gruzdo }, { id: a.shubin }, { id: a.kobziev }]);

  // VIII. Виставки
  const insEx = db.prepare('INSERT INTO exhibitions(developers,exhibit_name,exhibition_name,date_place,awards,year) VALUES(?,?,?,?,?,?)');
  insEx.run('Ховрат А.В., Кобзєв В.Г.', 'Система виявлення фейкового аудіо (демостенд)',
    'Інноваційні технології в науці та освіті', 'Жовтень 2025, Харків, ХНУРЕ', 'Диплом І ступеня', 2025);
  insEx.run('Гоцуляк К.О., Головашенко І.В.', 'Програмна система аналізу медичних зображень',
    'Молодіжний науковий форум', 'Квітень 2026, Харків', 'Грамота', 2026);
  insEx.run('Бондаренко І.М., Груздо І.В.', 'Платформа моніторингу навчального процесу',
    'Виставка-форум «Освіта та карʼєра»', 'Березень 2025, Київ', 'Срібна медаль', 2025);
  insEx.run('Смеляков К.С., Ховрат А.В.', 'Система розпізнавання обʼєктів для промислового IoT',
    'Hi-Tech Office Expo', 'Лютий 2026, Харків', 'Диплом учасника', 2026);
  insEx.run('Мороз К.І.', 'Мобільний застосунок стиснення зображень',
    'Студентська виставка інновацій', 'Жовтень 2024, Харків, ХНУРЕ', 'Грамота', 2024);

  // IX. Патенти / охоронні документи
  const insPat = db.prepare('INSERT INTO patents(count,theme_no,kind,supervisor,title,year) VALUES(?,?,?,?,?,?)');
  insPat.run(1, '№ 129101 від 19 серпня 2024 р.', 'applied', 'Олійник О.В., Олійник О.О.',
    'Патент на корисну модель', 2024);
  insPat.run(1, 'Свід. № 129731 від 09.09.2024', 'applied', 'Деркач А.С., Черепанова Ю.Ю.',
    "Комп'ютерна програма «EduGuide: система для пошуку та управління даними ЗВО та спеціальностей України»", 2024);
  insPat.run(1, 'Свід. № 131204 від 14.02.2025', 'applied', 'Кобзєв В.Г., Ховрат А.В.',
    "Комп'ютерна програма «Система обліку наукових публікацій кафедри»", 2025);
  insPat.run(1, '№ 132550 від 30.05.2025', 'fundamental', 'Бодянський Є.В., Мельник О.В.',
    'Спосіб кластеризації потокових даних на основі адаптивного резонансу', 2025);
  insPat.run(2, 'Свід. № 130880, № 130881 від 11.11.2024', 'applied', 'Груздо І.В., Бондаренко І.М.',
    "Комп'ютерні програми платформи моніторингу навчального процесу", 2024);

  // Розробки, впроваджені за межами університету
  const insDev = db.prepare('INSERT INTO developments(title_authors,indicators,place,act_date,results,framework,year) VALUES(?,?,?,?,?,?,?)');
  insDev.run('Система обліку наукових публікацій (Кобзєв В.Г., Ховрат А.В.)',
    'Автоматизація формування звітних таблиць; зниження ручної праці у 5+ разів',
    'Кафедра програмної інженерії, ХНУРЕ, м. Харків',
    '2026-05-15', 'Впроваджено у щорічну звітність кафедри', 'ініціативна робота', 2026);
  insDev.run('Платформа моніторингу навчального процесу (Груздо І.В., Бондаренко І.М.)',
    'Скорочення часу формування відомостей на 40%; інтеграція з деканатом',
    'Деканат факультету КН, ХНУРЕ, м. Харків',
    '2025-03-20', 'Прийнято в дослідну експлуатацію', 'госпдоговір № 45/24', 2025);
  insDev.run('Модуль розпізнавання обʼєктів для промислового IoT (Смеляков К.С.)',
    'Точність розпізнавання 94%; робота в реальному часі на edge-пристроях',
    'ТОВ «ІТ-Інтеграція», м. Харків',
    '2026-02-10', 'Впроваджено у пілотний проєкт замовника', 'госпдоговір № 12/25', 2026);
  insDev.run('Чат-бот технічної підтримки на основі LLM (Ткаченко О.П., Кобзєв В.Г.)',
    'Автоматизація 70% типових звернень; середній час відповіді < 2 с',
    'Служба підтримки ТОВ «СофтСервіс», м. Львів',
    '2025-11-05', 'Введено в промислову експлуатацію', 'госпдоговір № 33/25', 2025);
  insDev.run('Бібліотека lock-free контейнерів для високонавантажених систем (Ховрат А.В., Кобзєв В.Г.)',
    'Зростання пропускної здатності на 35% під багатопотоковим навантаженням',
    'ТОВ «Клауд Системс», м. Київ',
    '2024-12-18', 'Інтегровано у бекенд замовника', 'госпдоговір № 7/24', 2024);
  insDev.run('Система кластеризації потокових даних (Бодянський Є.В., Мельник О.В.)',
    'Обробка потоку до 100k подій/с; адаптивне донавчання без зупинки',
    'Аналітичний центр НДІ, м. Харків',
    '2025-04-22', 'Передано для дослідної експлуатації', 'держбюджетна тема № 0124U001234', 2025);
  insDev.run('Веб-платформа обліку успішності студентів (Сидоренко В.В., Груздо І.В.)',
    'Електронні відомості; зниження паперового документообігу на 60%',
    'Деканат ІКФ, ХНУРЕ, м. Харків',
    '2025-09-30', 'Прийнято в дослідну експлуатацію', 'ініціативна робота', 2025);
  insDev.run('Мобільний застосунок стиснення зображень (Мороз К.І., Шубін І.Ю.)',
    'Економія до 45% трафіку без помітної втрати якості',
    'Стартап «PixSave», м. Дніпро',
    '2026-01-12', 'Опубліковано в магазині застосунків', 'друга половина дня викладача', 2026);

  console.log('[db] Демонстраційні дані додано (розширений набір).');
}
