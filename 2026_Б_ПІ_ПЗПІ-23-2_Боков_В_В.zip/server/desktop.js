// Десктоп-обгортка: запускає локальний сервер і відкриває окреме вікно
// застосунку через системний Chrome/Edge у режимі --app (без вкладок і адресного рядка).
// Жодних важких залежностей — використовується вже встановлений браузер.
// Пріоритет: Chrome -> Edge (можна явно задати через BROWSER_PATH).
import { spawn } from 'node:child_process';
import { existsSync, rmSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import './index.js'; // стартує Express-сервер на :PORT

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const URL = `http://localhost:${PORT}`;

const candidates = [
  process.env.BROWSER_PATH,
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  process.env.LOCALAPPDATA ? process.env.LOCALAPPDATA + '/Google/Chrome/Application/chrome.exe' : null,
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
].filter(Boolean);
const browser = candidates.find((p) => existsSync(p));
const profileDir = path.join(__dirname, '..', '.appwindow');

// Невелика затримка, щоб сервер устиг піднятися.
setTimeout(() => {
  if (!browser) {
    console.log(`\n[desktop] Edge/Chrome не знайдено. Відкрийте вручну: ${URL}\n` +
      `(або вкажіть шлях у змінній середовища BROWSER_PATH)`);
    return;
  }
  const child = spawn(browser, [
    `--app=${URL}`,
    '--window-size=1320,880',
    `--user-data-dir=${profileDir}`,
    '--no-first-run',
    '--no-default-browser-check',
  ], { stdio: 'ignore' });

  console.log(`\n[desktop] Застосунок відкрито у власному вікні (${path.basename(browser)} --app).`);
  console.log('[desktop] Закриття вікна зупинить і сервер.\n');

  // Видалити тимчасовий профіль браузера (.appwindow), щоб не накопичувався мотлох.
  const cleanupProfile = () => {
    try { rmSync(profileDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch { }
  };

  // Коли вікно застосунку закрите — чистимо профіль і завершуємо процес (і сервер).
  child.on('exit', () => { cleanupProfile(); process.exit(0); });
  // Підстраховка: якщо процес завершують іншим способом (Ctrl+C тощо).
  process.on('SIGINT', () => { cleanupProfile(); process.exit(0); });
  process.on('exit', cleanupProfile);
}, 700);
