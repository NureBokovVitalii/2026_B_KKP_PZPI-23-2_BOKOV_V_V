// REST API + бізнес-логіка (обчислення авт. аркушів, віку <35, агрегати звітів).
import { Router } from 'express';
import { db } from './db.js';
import { buildXlsx } from './xlsx.js';
import { buildDocx } from './docx.js';
import { login, logout, requireAuth, ROLES, listUsers, createUser, updateUser, deleteUser } from './auth.js';

// Усі таблиці даних (у порядку, безпечному для вставки з урахуванням зовнішніх ключів).
const DB_TABLES = ['organizations', 'specialties', 'venues', 'authors', 'publications',
  'publication_authors', 'name_history', 'exhibitions', 'patents', 'developments'];

export function createApi() {
  const r = Router();

  // ===================== АВТЕНТИФІКАЦІЯ ТА РОЛІ =====================
  // Публічний вхід
  r.post('/login', (q, s) => {
    const { username, password } = q.body || {};
    const res = login(username, password);
    if (!res) return s.status(401).json({ error: 'Невірний логін або пароль' });
    s.json(res);
  });
  r.get('/roles', (_q, s) => s.json(ROLES));

  // Усе нижче потребує валідної сесії
  r.use(requireAuth);

  // Поточний користувач / вихід (дозволено будь-якій ролі)
  r.get('/me', (q, s) => s.json({ user: { username: q.user.username, role: q.user.role, full_name: q.user.full_name } }));
  r.post('/logout', (q, s) => { const t = (q.headers.authorization || '').slice(7); logout(t); s.json({ ok: true }); });

  // Рольовий шлюз для решти маршрутів:
  //  - supervisor: усе;
  //  - адмін-зони (/users, бекап /export/db, /import/db): лише supervisor;
  //  - write: будь-які дії з даними (GET/POST/PUT/DELETE), окрім адмін-зон;
  //  - read: лише GET.
  r.use((q, s, next) => {
    const role = q.user.role;
    if (role === 'supervisor') return next();
    const p = q.path;
    const adminZone = p.startsWith('/users') || p.startsWith('/export/db') || p.startsWith('/import/db');
    if (adminZone) return s.status(403).json({ error: 'Доступ лише для адміністратора' });
    if (role === 'write') return next();
    if (role === 'read' && q.method === 'GET') return next();
    return s.status(403).json({ error: 'Лише перегляд: редагування заборонено для цієї ролі' });
  });

  // CRUD користувачів (шлюз вище вже допускає сюди лише supervisor)
  r.get('/users', (_q, s) => s.json(listUsers()));
  r.post('/users', (q, s) => {
    try { s.status(201).json(createUser(q.body || {})); } catch (e) { s.status(400).json({ error: e.message }); }
  });
  r.put('/users/:id', (q, s) => {
    const tok = (q.headers.authorization || '').slice(7);
    try { s.json(updateUser(+q.params.id, q.body || {}, tok)); } catch (e) { s.status(400).json({ error: e.message }); }
  });
  r.delete('/users/:id', (q, s) => {
    try { deleteUser(+q.params.id); s.json({ ok: true }); } catch (e) { s.status(400).json({ error: e.message }); }
  });
  // ================================================================

  // ---------- довідкові переліки (enum) ----------
  r.get('/meta', (_req, res) => res.json({
    author_roles: { teacher: 'Викладач', student: 'Студент', master: 'Магістрант', phd: 'Аспірант', pupil: 'Ліцеїст' },
    pub_types: { article: 'Стаття', theses: 'Тези', report: 'Доповідь' },
    pub_categories: {
      article_ua: 'I. Стаття у виданні України',
      article_foreign: 'II. Стаття у зарубіжному виданні',
      conf_ua: 'III. Конференція по Україні',
      conf_foreign: 'IV. Конференція за кордоном',
      prep_foreign: 'V. Підготовлено до друку (закордон)',
      monograph: 'VI. Монографія',
      textbook: 'VII. Підручник / посібник',
    },
    indexation: { none: 'Немає', scopus: 'Scopus', wos: 'Web of Science', scopus_wos: 'Scopus + WoS' },
    org_types: { our_dept: 'Наша кафедра', our_univ: 'Наш університет', external: 'Сторонній ВНЗ/орг.', foreign: 'Іноземна' },
    venue_kinds: { journal: 'Журнал', conference: 'Конференція' },
    pub_author_roles: { author: 'Автор', advisor: 'Науковий керівник', coauthor: 'Співавтор' },
    languages: { uk: 'Українська', en: 'Англійська', de: 'Німецька' },
    patent_kinds: { fundamental: 'Фундаментальна', applied: 'Прикладна' },
  }));

  // ---------- обчислювані величини ----------
  const pagesOf = (p) =>
    (Number.isInteger(p.page_from) && Number.isInteger(p.page_to)) ? (p.page_to - p.page_from + 1) : null;

  const gcd = (a, b) => b ? gcd(b, a % b) : a;
  const sheetsOf = (pages) => {
    if (pages == null) return null;
    const g = gcd(pages, 12) || 1;
    return { decimal: +(pages / 12).toFixed(2), fraction: `${pages / g}/${12 / g}` };
  };

  function publicationsWithAuthors(where = '', params = []) {
    const pubs = db.prepare(`
      SELECT p.*, v.name AS venue_name, v.indexation AS venue_indexation, v.kind AS venue_kind,
             sp.code AS specialty_code
      FROM publications p
      LEFT JOIN venues v ON v.id = p.venue_id
      LEFT JOIN specialties sp ON sp.id = v.specialty_id
      ${where} ORDER BY p.year DESC, p.id DESC`).all(...params);
    const paStmt = db.prepare(`
      SELECT pa.*, a.full_name_uk, a.full_name_en, a.birth_year, a.is_foreign, a.role AS author_role,
             o.name AS org_name, o.type AS org_type
      FROM publication_authors pa
      JOIN authors a ON a.id = pa.author_id
      LEFT JOIN organizations o ON o.id = a.organization_id
      WHERE pa.publication_id = ? ORDER BY pa.ord`);
    return pubs.map((p) => {
      const pages = pagesOf(p);
      const authors = paStmt.all(p.id).map((pa) => {
        const age = (p.year && pa.birth_year) ? (p.year - pa.birth_year) : null;
        return {
          author_id: pa.author_id, ord: pa.ord, role_in_pub: pa.role_in_pub,
          is_student: !!pa.is_student, is_foreign: !!pa.is_foreign, presented: !!pa.presented,
          name_uk: pa.full_name_uk, name_en: pa.full_name_en, birth_year: pa.birth_year,
          org_name: pa.org_name, org_type: pa.org_type,
          age_at_pub: age, under35: age == null ? null : age < 35,
        };
      });
      return {
        ...p, scopus: !!p.scopus, wos: !!p.wos,
        is_professional: !!p.is_professional, impact_factor: !!p.impact_factor, gryf_mon: !!p.gryf_mon,
        pages, author_sheets: sheetsOf(pages),
        authors,
        has_foreign: authors.some((x) => x.is_foreign),
        has_young: authors.some((x) => x.under35 === true),
      };
    });
  }

  // ---------- ОРГАНІЗАЦІЇ ----------
  r.get('/organizations', (_q, s) => s.json(db.prepare('SELECT * FROM organizations ORDER BY name').all()));
  r.post('/organizations', (q, s) => {
    const { name, type = 'external', country = null } = q.body || {};
    if (!name) return s.status(400).json({ error: 'name обовʼязковий' });
    const id = db.prepare('INSERT INTO organizations(name,type,country) VALUES(?,?,?)').run(name, type, country).lastInsertRowid;
    s.status(201).json(db.prepare('SELECT * FROM organizations WHERE id=?').get(id));
  });
  r.delete('/organizations/:id', (q, s) => { db.prepare('DELETE FROM organizations WHERE id=?').run(q.params.id); s.json({ ok: true }); });

  // ---------- СПЕЦІАЛЬНОСТІ ----------
  r.get('/specialties', (_q, s) => s.json(db.prepare('SELECT * FROM specialties ORDER BY code').all()));
  r.post('/specialties', (q, s) => {
    const { code, name } = q.body || {};
    if (!code || !name) return s.status(400).json({ error: 'code і name обовʼязкові' });
    const id = db.prepare('INSERT INTO specialties(code,name) VALUES(?,?)').run(code, name).lastInsertRowid;
    s.status(201).json(db.prepare('SELECT * FROM specialties WHERE id=?').get(id));
  });
  r.delete('/specialties/:id', (q, s) => { db.prepare('DELETE FROM specialties WHERE id=?').run(q.params.id); s.json({ ok: true }); });

  // ---------- ВИДАННЯ / КОНФЕРЕНЦІЇ ----------
  r.get('/venues', (_q, s) => s.json(db.prepare(`
    SELECT v.*, sp.code AS specialty_code FROM venues v
    LEFT JOIN specialties sp ON sp.id = v.specialty_id ORDER BY v.name`).all()));
  r.post('/venues', (q, s) => {
    const { name, kind = 'conference', country = null, specialty_id = null, indexation = 'none' } = q.body || {};
    if (!name) return s.status(400).json({ error: 'name обовʼязковий' });
    const id = db.prepare('INSERT INTO venues(name,kind,country,specialty_id,indexation) VALUES(?,?,?,?,?)')
      .run(name, kind, country, specialty_id, indexation).lastInsertRowid;
    s.status(201).json(db.prepare('SELECT * FROM venues WHERE id=?').get(id));
  });
  r.delete('/venues/:id', (q, s) => { db.prepare('DELETE FROM venues WHERE id=?').run(q.params.id); s.json({ ok: true }); });

  // ---------- АВТОРИ ----------
  r.get('/authors', (_q, s) => s.json(db.prepare(`
    SELECT a.*, o.name AS org_name, o.type AS org_type FROM authors a
    LEFT JOIN organizations o ON o.id = a.organization_id ORDER BY a.full_name_uk`).all()
    .map(a => ({ ...a, is_foreign: !!a.is_foreign }))));
  const authorValues = (b) => [
    b.full_name_uk, b.full_name_en ?? null, b.role ?? 'teacher', b.birth_year ?? null,
    b.organization_id ?? null, b.is_foreign ? 1 : 0, b.academic_title ?? null,
    b.orcid ?? null, b.scopus_id ?? null, b.researcher_id ?? null, b.google_scholar ?? null,
  ];
  r.post('/authors', (q, s) => {
    const b = q.body || {};
    if (!b.full_name_uk) return s.status(400).json({ error: 'full_name_uk обовʼязковий' });
    const id = db.prepare(`INSERT INTO authors(full_name_uk,full_name_en,role,birth_year,organization_id,is_foreign,academic_title,orcid,scopus_id,researcher_id,google_scholar)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(...authorValues(b)).lastInsertRowid;
    s.status(201).json(db.prepare('SELECT * FROM authors WHERE id=?').get(id));
  });
  r.put('/authors/:id', (q, s) => {
    const id = q.params.id; const b = q.body || {};
    if (!db.prepare('SELECT id FROM authors WHERE id=?').get(id)) return s.status(404).json({ error: 'не знайдено' });
    if (!b.full_name_uk) return s.status(400).json({ error: 'full_name_uk обовʼязковий' });
    db.prepare(`UPDATE authors SET full_name_uk=?,full_name_en=?,role=?,birth_year=?,organization_id=?,is_foreign=?,academic_title=?,orcid=?,scopus_id=?,researcher_id=?,google_scholar=? WHERE id=?`)
      .run(...authorValues(b), id);
    s.json(db.prepare('SELECT * FROM authors WHERE id=?').get(id));
  });
  r.delete('/authors/:id', (q, s) => { db.prepare('DELETE FROM authors WHERE id=?').run(q.params.id); s.json({ ok: true }); });

  // зміна ПІБ (історія)
  r.post('/authors/:id/rename', (q, s) => {
    const id = q.params.id;
    const a = db.prepare('SELECT * FROM authors WHERE id=?').get(id);
    if (!a) return s.status(404).json({ error: 'автора не знайдено' });
    const { new_name, changed_on = null } = q.body || {};
    if (!new_name) return s.status(400).json({ error: 'new_name обовʼязковий' });
    db.prepare('INSERT INTO name_history(author_id,old_name,new_name,changed_on) VALUES(?,?,?,?)')
      .run(id, a.full_name_uk, new_name, changed_on);
    db.prepare('UPDATE authors SET full_name_uk=? WHERE id=?').run(new_name, id);
    s.json({ ok: true });
  });
  r.get('/authors/:id/history', (q, s) =>
    s.json(db.prepare('SELECT * FROM name_history WHERE author_id=? ORDER BY id DESC').all(q.params.id)));

  // ---------- ПУБЛІКАЦІЇ ----------
  // Фільтрація публікацій за параметрами (UC-5 пошук/перевірка, UC-3 період/автор).
  function filteredPublications(query = {}) {
    const where = [], params = [];
    if (query.year_from) { where.push('p.year >= ?'); params.push(+query.year_from); }
    if (query.year_to) { where.push('p.year <= ?'); params.push(+query.year_to); }
    if (query.type) { where.push('p.type = ?'); params.push(query.type); }
    if (query.category) { where.push('p.category = ?'); params.push(query.category); }
    if (query.scopus === '1') where.push('p.scopus = 1');
    if (query.wos === '1') where.push('p.wos = 1');
    if (query.indexed === '1') where.push('(p.scopus = 1 OR p.wos = 1)');
    const sql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    let rows = publicationsWithAuthors(sql, params);
    // Пост-фільтри по повʼязаних авторах та тексту:
    if (query.author_id) {
      const aid = +query.author_id;
      rows = rows.filter(p => p.authors.some(a => a.author_id === aid));
    }
    if (query.foreign === '1') rows = rows.filter(p => p.has_foreign);
    if (query.young === '1') rows = rows.filter(p => p.has_young);
    if (query.search) {
      const q = String(query.search).toLowerCase();
      rows = rows.filter(p =>
        (p.title && p.title.toLowerCase().includes(q)) ||
        (p.keywords && p.keywords.toLowerCase().includes(q)) ||
        (p.venue_name && p.venue_name.toLowerCase().includes(q)) ||
        (p.doi && p.doi.toLowerCase().includes(q)) ||
        p.authors.some(a => (a.name_uk && a.name_uk.toLowerCase().includes(q)) || (a.name_en && a.name_en.toLowerCase().includes(q)))
      );
    }
    return rows;
  }
  r.get('/publications', (q, s) => s.json(filteredPublications(q.query)));
  r.get('/publications/:id', (q, s) => {
    const rows = publicationsWithAuthors('WHERE p.id=?', [q.params.id]);
    rows.length ? s.json(rows[0]) : s.status(404).json({ error: 'не знайдено' });
  });
  const pubValues = (b) => [
    b.title, b.type ?? 'article', b.category ?? null, b.venue_id ?? null, b.year ?? null, b.pub_date ?? null, b.place ?? null,
    b.page_from ?? null, b.page_to ?? null, b.doi ?? null, b.url ?? null, b.language ?? 'uk',
    b.scopus ? 1 : 0, b.wos ? 1 : 0, b.is_professional ? 1 : 0, b.impact_factor ? 1 : 0, b.gryf_mon ? 1 : 0,
    b.scimetric_base ?? null, b.volume_issue ?? null, b.citations ?? 0, b.keywords ?? null, b.abstract ?? null,
  ];
  const PUB_COLS = 'title,type,category,venue_id,year,pub_date,place,page_from,page_to,doi,url,language,scopus,wos,is_professional,impact_factor,gryf_mon,scimetric_base,volume_issue,citations,keywords,abstract';
  const insPA = db.prepare('INSERT INTO publication_authors(publication_id,author_id,ord,role_in_pub,is_student,presented) VALUES(?,?,?,?,?,?)');
  const setAuthors = (pubId, authors) => {
    db.prepare('DELETE FROM publication_authors WHERE publication_id=?').run(pubId);
    (authors || []).forEach((au, i) => insPA.run(pubId, au.author_id, au.ord ?? i + 1, au.role_in_pub ?? 'author', au.is_student ? 1 : 0, au.presented ? 1 : 0));
  };
  r.post('/publications', (q, s) => {
    const b = q.body || {};
    if (!b.title) return s.status(400).json({ error: 'title обовʼязковий' });
    const ph = PUB_COLS.split(',').map(() => '?').join(',');
    const id = db.prepare(`INSERT INTO publications (${PUB_COLS}) VALUES(${ph})`).run(...pubValues(b)).lastInsertRowid;
    if (Array.isArray(b.authors)) setAuthors(id, b.authors);
    s.status(201).json(publicationsWithAuthors('WHERE p.id=?', [id])[0]);
  });
  r.put('/publications/:id', (q, s) => {
    const id = q.params.id; const b = q.body || {};
    if (!db.prepare('SELECT id FROM publications WHERE id=?').get(id)) return s.status(404).json({ error: 'не знайдено' });
    if (!b.title) return s.status(400).json({ error: 'title обовʼязковий' });
    const setClause = PUB_COLS.split(',').map((c) => `${c}=?`).join(',');
    db.prepare(`UPDATE publications SET ${setClause} WHERE id=?`).run(...pubValues(b), id);
    if (Array.isArray(b.authors)) setAuthors(id, b.authors);
    s.json(publicationsWithAuthors('WHERE p.id=?', [id])[0]);
  });
  r.delete('/publications/:id', (q, s) => { db.prepare('DELETE FROM publications WHERE id=?').run(q.params.id); s.json({ ok: true }); });

  // ---------- ВИСТАВКИ / ПАТЕНТИ / РОЗРОБКИ (CRUD) ----------
  function crud(route, table, cols) {
    const list = cols.split(',');
    r.get(route, (_q, s) => s.json(db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all()));
    r.post(route, (q, s) => {
      const b = q.body || {};
      const ph = list.map(() => '?').join(',');
      const id = db.prepare(`INSERT INTO ${table} (${cols}) VALUES(${ph})`).run(...list.map((c) => b[c] ?? null)).lastInsertRowid;
      s.status(201).json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(id));
    });
    r.put(`${route}/:id`, (q, s) => {
      const b = q.body || {};
      if (!db.prepare(`SELECT id FROM ${table} WHERE id=?`).get(q.params.id)) return s.status(404).json({ error: 'не знайдено' });
      const setClause = list.map((c) => `${c}=?`).join(',');
      db.prepare(`UPDATE ${table} SET ${setClause} WHERE id=?`).run(...list.map((c) => b[c] ?? null), q.params.id);
      s.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(q.params.id));
    });
    r.delete(`${route}/:id`, (q, s) => { db.prepare(`DELETE FROM ${table} WHERE id=?`).run(q.params.id); s.json({ ok: true }); });
  }
  crud('/exhibitions', 'exhibitions', 'developers,exhibit_name,exhibition_name,date_place,awards,year');
  crud('/patents', 'patents', 'count,theme_no,kind,supervisor,title,year');
  crud('/developments', 'developments', 'title_authors,indicators,place,act_date,results,framework,year');

  // ---------- РЕДАГУВАННЯ ДОВІДНИКІВ ----------
  r.put('/organizations/:id', (q, s) => {
    const b = q.body || {};
    db.prepare('UPDATE organizations SET name=?,type=?,country=? WHERE id=?')
      .run(b.name, b.type ?? 'external', b.country ?? null, q.params.id);
    s.json(db.prepare('SELECT * FROM organizations WHERE id=?').get(q.params.id));
  });
  r.put('/venues/:id', (q, s) => {
    const b = q.body || {};
    db.prepare('UPDATE venues SET name=?,kind=?,country=?,specialty_id=?,indexation=? WHERE id=?')
      .run(b.name, b.kind ?? 'conference', b.country ?? null, b.specialty_id ?? null, b.indexation ?? 'none', q.params.id);
    s.json(db.prepare('SELECT * FROM venues WHERE id=?').get(q.params.id));
  });
  r.put('/specialties/:id', (q, s) => {
    const b = q.body || {};
    db.prepare('UPDATE specialties SET code=?,name=? WHERE id=?').run(b.code, b.name, q.params.id);
    s.json(db.prepare('SELECT * FROM specialties WHERE id=?').get(q.params.id));
  });

  // ---------- ЗВІТИ ----------
  const toCSV = (rows) => {
    if (!rows.length) return '';
    const cols = Object.keys(rows[0]);
    const esc = (x) => `"${String(x ?? '').replace(/"/g, '""')}"`;
    return '﻿' + [cols.join(';'), ...rows.map(r => cols.map(c => esc(r[c])).join(';'))].join('\r\n');
  };
  const send = (res, req, rows, name) => {
    if ((req.query.format || '') === 'csv') {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${name}.csv"`);
      return res.send(toCSV(rows));
    }
    res.json(rows);
  };
  const authorsLine = (p) => p.authors.map(a => {
    const tags = [];
    if (a.is_student) tags.push('студ');
    if (a.role_in_pub === 'advisor') tags.push('наук.керівн');
    if (a.is_foreign) tags.push('іноз. співавтор');
    return a.name_uk + (tags.length ? ` (${tags.join(', ')})` : '');
  }).join('; ');

  // Розбивка авторів за віком (до/після 35) — як у звітних формах кафедри
  const young = (p) => p.authors.filter(a => a.under35 === true)
    .map(a => a.name_uk + (a.presented ? ' (доповідав)' : '')).join('; ');
  const senior = (p) => p.authors.filter(a => a.under35 === false)
    .map(a => a.name_uk + (a.presented ? ' (доповідав)' : '')).join('; ');
  const sheets = (p) => p.author_sheets ? p.author_sheets.decimal : '';

  // Публікації з урахуванням параметрів звіту (період/автор) + фіксованих обмежень форми.
  const pubsFor = (q = {}, fixed = {}) => filteredPublications({
    year_from: q.year_from, year_to: q.year_to, author_id: q.author_id, ...fixed,
  });

  // Рядки звітної форми по публікаціях певної категорії (з параметрами q)
  const categoryRows = (category, q = {}) =>
    pubsFor(q, { category }).map((p, i) => ({
      '№': i + 1,
      'Автори до 35': young(p),
      'Автори після 35': senior(p),
      'Назва роботи': p.title,
      'Видання / місце': [p.venue_name, p.place].filter(Boolean).join(', '),
      'Наукометр. база / ІФ': p.scimetric_base ?? (p.scopus ? 'Scopus' : ''),
      'Том/випуск': p.volume_issue ?? '',
      'Рік': p.year ?? '',
      'Стор.': p.pages ?? '',
      'Авт. аркуші': sheets(p),
      'Фахове': p.is_professional ? 'так' : '',
      'Імпакт-фактор': p.impact_factor ? 'так' : '',
    }));
  const PATENT_KINDS = { fundamental: 'Фундаментальна', applied: 'Прикладна' };

  // Реєстр звітів: ключ -> { sheet, file, title (для Word), rows(q) }.
  // q містить year_from/year_to/author_id (UC-3). Звіти по сутностях (виставки/патенти/розробки)
  // фільтруються лише за роком.
  const yearFilter = (rows, q) => rows.filter(x =>
    (!q.year_from || (x.year != null && x.year >= +q.year_from)) &&
    (!q.year_to || (x.year != null && x.year <= +q.year_to)));
  const REPORTS = {
    article_ua: { sheet: 'I Статті Укр', file: 'I_statti_ukrayina', title: 'I. Статті, опубліковані в періодичних виданнях України', rows: (q) => categoryRows('article_ua', q) },
    article_foreign: { sheet: 'II Статті закорд', file: 'II_statti_zakordon', title: 'II. Статті у зарубіжних виданнях', rows: (q) => categoryRows('article_foreign', q) },
    conf_ua: { sheet: 'III Конф Укр', file: 'III_konferentsiyi_ukrayina', title: 'III. Конференції по Україні', rows: (q) => categoryRows('conf_ua', q) },
    conf_foreign: { sheet: 'IV Конф закорд', file: 'IV_konferentsiyi_zakordon', title: 'IV. Конференції за кордоном', rows: (q) => categoryRows('conf_foreign', q) },
    prep_foreign: { sheet: 'V Підгот закорд', file: 'V_pidgotovleni_zakordon', title: 'V. Підготовлені до друку (закордон)', rows: (q) => categoryRows('prep_foreign', q) },
    monograph: { sheet: 'VI Монографії', file: 'VI_monografiyi', title: 'VI. Монографії', rows: (q) => categoryRows('monograph', q) },
    textbook: { sheet: 'VII Підручники', file: 'VII_pidruchnyky', title: 'VII. Підручники, навчальні посібники', rows: (q) => categoryRows('textbook', q) },
    exhibitions: {
      sheet: 'VIII Виставки', file: 'VIII_vystavky', title: 'VIII. Участь у виставках', rows: (q) =>
        yearFilter(db.prepare('SELECT * FROM exhibitions ORDER BY year DESC, id DESC').all(), q).map((e, i) => ({
          '№': i + 1, 'Розроблювачі': e.developers ?? '', 'Експонат': e.exhibit_name,
          'Виставка': e.exhibition_name ?? '', 'Дата й місце': e.date_place ?? '', 'Нагороди': e.awards ?? '', 'Рік': e.year ?? '',
        })),
    },
    patents: {
      sheet: 'IX Патенти', file: 'IX_patenty', title: 'IX. Патенти / охоронні документи', rows: (q) =>
        yearFilter(db.prepare('SELECT * FROM patents ORDER BY year DESC, id DESC').all(), q).map((p, i) => ({
          '№': i + 1, 'К-сть патентів': p.count, 'Назва / реєстр. дані': [p.title, p.theme_no].filter(Boolean).join('. '),
          'Тип': PATENT_KINDS[p.kind] ?? p.kind, 'Науковий керівник': p.supervisor ?? '', 'Рік': p.year ?? '',
        })),
    },
    developments: {
      sheet: 'Розробки', file: 'rozrobky', title: 'Розробки, впроваджені поза університетом', rows: (q) =>
        yearFilter(db.prepare('SELECT * FROM developments ORDER BY year DESC, id DESC').all(), q).map((d, i) => ({
          '№': i + 1, 'Назва та автори': d.title_authors, 'Показники / переваги': d.indicators ?? '',
          'Місце впровадження': d.place ?? '', 'Дата акту': d.act_date ?? '', 'Результати': d.results ?? '', 'У рамках': d.framework ?? '', 'Рік': d.year ?? '',
        })),
    },
    'all-works': {
      sheet: 'Перелік праць', file: 'perelik_prats', title: 'Перелік праць', rows: (q) =>
        pubsFor(q).map((p, i) => ({
          '№': i + 1, 'Назва': p.title, 'Характер': ({ article: 'Стаття', theses: 'Тези', report: 'Доповідь' })[p.type] ?? p.type,
          'Вихідні дані': [p.venue_name, p.volume_issue, p.place, p.doi].filter(Boolean).join(', '),
          'Обсяг (стор.)': p.pages ?? '', 'Співавтори': authorsLine(p), 'Рік': p.year ?? '',
          'Ключові слова': p.keywords ?? '', 'Спеціальність': p.specialty_code ?? '',
          'Scopus': p.scopus ? 'так' : '', 'WoS': p.wos ? 'так' : '', 'Посилання': p.url ?? p.doi ?? '',
        })),
    },
    scopus: {
      sheet: 'Scopus-WoS', file: 'zvit_scopus_wos', title: 'Публікації у Scopus / Web of Science', rows: (q) =>
        pubsFor(q, { indexed: '1' }).map(p => ({
          Назва: p.title, Тип: p.type, Видання: p.venue_name, Рік: p.year,
          Сторінки: p.pages, 'Авт.аркуші': p.author_sheets?.fraction ?? '', DOI: p.doi ?? '',
          Індексація: [p.scopus && 'Scopus', p.wos && 'WoS'].filter(Boolean).join('+'), Автори: authorsLine(p),
        })),
    },
    foreign: {
      sheet: 'Іноземні співавтори', file: 'zvit_inozemni_spivavtory', title: 'Публікації з іноземними співавторами', rows: (q) =>
        pubsFor(q, { foreign: '1' }).map(p => ({
          Назва: p.title, Видання: p.venue_name, Рік: p.year,
          'Іноземні співавтори': p.authors.filter(a => a.is_foreign).map(a => `${a.name_uk} (${a.org_name ?? ''})`).join('; '),
          Автори: authorsLine(p),
        })),
    },
    'by-age': {
      sheet: 'За віком', file: 'zvit_za_vikom', title: 'Публікації за віком авторів (<35)', rows: (q) =>
        pubsFor(q).map(p => ({
          Назва: p.title, Рік: p.year,
          'Є автор <35': p.has_young ? 'так' : 'ні',
          'Молоді автори (<35)': p.authors.filter(a => a.under35).map(a => `${a.name_uk} (${a.age_at_pub})`).join('; '),
          Автори: authorsLine(p),
        })),
    },
    'by-year': {
      sheet: 'За роками', file: 'zvit_za_rokamy', title: 'Публікації за роками', rows: (q) => {
        const map = {};
        for (const p of pubsFor(q)) {
          const k = p.year ?? '—';
          map[k] ??= { Рік: k, Статті: 0, Тези: 0, Доповіді: 0, Scopus: 0, WoS: 0, Усього: 0 };
          if (p.type === 'article') map[k].Статті++; else if (p.type === 'theses') map[k].Тези++; else map[k].Доповіді++;
          if (p.scopus) map[k].Scopus++; if (p.wos) map[k].WoS++; map[k].Усього++;
        }
        return Object.values(map).sort((a, b) => String(b.Рік).localeCompare(String(a.Рік)));
      },
    },
  };

  // Підпис періоду/автора для шапки експорту
  const periodNote = (q) => {
    const parts = [];
    if (q.year_from || q.year_to) parts.push(`Період: ${q.year_from || '...'}–${q.year_to || '...'}`);
    if (q.author_id) { const a = db.prepare('SELECT full_name_uk FROM authors WHERE id=?').get(+q.author_id); if (a) parts.push(`Автор: ${a.full_name_uk}`); }
    return parts.join('; ');
  };

  // Один маршрут на всі звіти: JSON, ?format=csv | xlsx | docx (+ параметри period/author)
  for (const [key, def] of Object.entries(REPORTS)) {
    r.get('/reports/' + key, (q, s) => {
      const rows = def.rows(q.query || {});
      const fmt = q.query.format || '';
      if (fmt === 'xlsx') {
        const buf = buildXlsx([{ name: def.sheet, rows: rowsToAoa(rows) }]);
        s.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        s.setHeader('Content-Disposition', `attachment; filename="${def.file}.xlsx"`);
        return s.send(buf);
      }
      if (fmt === 'docx') {
        const buf = buildDocx(def.title, rowsToAoa(rows), periodNote(q.query));
        s.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        s.setHeader('Content-Disposition', `attachment; filename="${def.file}.docx"`);
        return s.send(buf);
      }
      send(s, q, rows, def.file);
    });
  }

  // Перетворення масиву обʼєктів у «масив масивів» (рядок 0 — заголовки) для xlsx
  function rowsToAoa(rows) {
    if (!rows.length) return [['(немає даних)']];
    const cols = Object.keys(rows[0]);
    return [cols, ...rows.map(r => cols.map(c => r[c] ?? ''))];
  }

  // Експорт УСІХ звітних форм одним .xlsx (кожна форма — окремий лист), з урахуванням параметрів
  r.get('/export/xlsx', (q, s) => {
    const order = ['article_ua', 'article_foreign', 'conf_ua', 'conf_foreign', 'prep_foreign',
      'monograph', 'textbook', 'exhibitions', 'patents', 'developments', 'all-works',
      'scopus', 'foreign', 'by-age', 'by-year'];
    const sheets = order.map(k => ({ name: REPORTS[k].sheet, rows: rowsToAoa(REPORTS[k].rows(q.query || {})) }));
    const buf = buildXlsx(sheets);
    s.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    s.setHeader('Content-Disposition', 'attachment; filename="zvitni_tablytsi.xlsx"');
    s.send(buf);
  });

  // ---------- РЕЗЕРВНА КОПІЯ / ВІДНОВЛЕННЯ БД ----------
  // Знімок усієї БД у переносний JSON (переживає зміни схеми: експортуються наявні колонки).
  function dumpDatabase() {
    const data = {};
    for (const t of DB_TABLES) {
      try { data[t] = db.prepare(`SELECT * FROM ${t}`).all(); } catch { data[t] = []; }
    }
    return { format: 'pub-accounting-backup', version: 1, tables: data };
  }

  // GET /export/db -> завантажити JSON-резервну копію
  r.get('/export/db', (_q, s) => {
    const snap = dumpDatabase();
    snap.exported_at_note = 'Резервна копія БД обліку публікацій';
    s.setHeader('Content-Type', 'application/json; charset=utf-8');
    s.setHeader('Content-Disposition', 'attachment; filename="pub-accounting-backup.json"');
    s.send(JSON.stringify(snap, null, 2));
  });

  // GET /export/db/stats -> скільки записів у кожній таблиці (для UI)
  r.get('/export/db/stats', (_q, s) => {
    const stats = {};
    for (const t of DB_TABLES) { try { stats[t] = db.prepare(`SELECT COUNT(*) c FROM ${t}`).get().c; } catch { stats[t] = 0; } }
    s.json(stats);
  });

  // POST /import/db -> відновити БД зі знімка (повна заміна даних). Body = той самий JSON.
  r.post('/import/db', (q, s) => {
    const body = q.body || {};
    const tables = body.tables || body; // приймаємо як {tables:{...}} так і голий {...}
    if (!tables || typeof tables !== 'object') return s.status(400).json({ error: 'Невірний формат файлу резервної копії' });
    const known = DB_TABLES.filter(t => Array.isArray(tables[t]));
    if (!known.length) return s.status(400).json({ error: 'У файлі немає відомих таблиць' });

    try {
      db.exec('PRAGMA foreign_keys = OFF');
      db.exec('BEGIN');
      // Очистити у зворотному порядку (діти -> батьки)
      for (const t of [...DB_TABLES].reverse()) { try { db.exec(`DELETE FROM ${t}`); } catch {} }
      let inserted = 0;
      for (const t of DB_TABLES) {
        const rows = tables[t]; if (!Array.isArray(rows) || !rows.length) continue;
        const cols = db.prepare(`PRAGMA table_info(${t})`).all().map(c => c.name);
        for (const row of rows) {
          const useCols = cols.filter(c => Object.prototype.hasOwnProperty.call(row, c));
          if (!useCols.length) continue;
          const ph = useCols.map(() => '?').join(',');
          db.prepare(`INSERT INTO ${t} (${useCols.join(',')}) VALUES(${ph})`).run(...useCols.map(c => row[c]));
          inserted++;
        }
      }
      db.exec('COMMIT');
      db.exec('PRAGMA foreign_keys = ON');
      s.json({ ok: true, restored_tables: known, inserted });
    } catch (e) {
      try { db.exec('ROLLBACK'); } catch {}
      db.exec('PRAGMA foreign_keys = ON');
      s.status(500).json({ error: 'Помилка відновлення: ' + e.message });
    }
  });

  r.get('/reports/summary', (_q, s) => {
    const all = publicationsWithAuthors();
    s.json({
      publications: all.length,
      articles: all.filter(p => p.type === 'article').length,
      theses: all.filter(p => p.type === 'theses').length,
      reports: all.filter(p => p.type === 'report').length,
      scopus: all.filter(p => p.scopus).length,
      wos: all.filter(p => p.wos).length,
      with_foreign: all.filter(p => p.has_foreign).length,
      with_young: all.filter(p => p.has_young).length,
      authors: db.prepare('SELECT COUNT(*) AS c FROM authors').get().c,
      exhibitions: db.prepare('SELECT COUNT(*) AS c FROM exhibitions').get().c,
      patents: db.prepare('SELECT COUNT(*) AS c FROM patents').get().c,
      developments: db.prepare('SELECT COUNT(*) AS c FROM developments').get().c,
    });
  });

  return r;
}
