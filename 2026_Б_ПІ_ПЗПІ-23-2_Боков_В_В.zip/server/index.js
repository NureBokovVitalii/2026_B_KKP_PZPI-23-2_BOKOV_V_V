import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApi } from './api.js';
import './db.js'; // ініціалізація БД + сидінг

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

const app = express();
app.use(express.json({ limit: '64mb' })); // запас для імпорту БД (JSON-знімок)

// Не кешувати статику клієнта — щоб браузер завжди брав свіжий app.js/index.html
// (інакше після оновлень може лишатися стара версія в кеші).
app.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

app.use('/api', createApi());
app.use(express.static(path.join(__dirname, '..', 'public'), { etag: false, lastModified: false, cacheControl: false }));

const server = app.listen(PORT, () => {
  console.log(`\n  Облік публікацій — застосунок запущено:`);
  console.log(`  → http://localhost:${PORT}\n  (Ctrl+C для зупинки)\n`);
});

// Зрозуміле повідомлення замість стектрейсу, якщо порт зайнятий
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n[ПОМИЛКА] Порт ${PORT} уже зайнятий — напевно вже запущено інший сервер застосунку.`);
    console.error(`  Закрийте старе вікно сервера і запустіть start.bat знову`);
    console.error(`  (start.bat тепер сам звільняє порт), або запустіть на іншому порту:`);
    console.error(`    set PORT=3001  та відкрийте http://localhost:3001\n`);
    process.exit(1);
  }
  console.error('[ПОМИЛКА] Сервер не зміг стартувати:', err.message);
  process.exit(1);
});
