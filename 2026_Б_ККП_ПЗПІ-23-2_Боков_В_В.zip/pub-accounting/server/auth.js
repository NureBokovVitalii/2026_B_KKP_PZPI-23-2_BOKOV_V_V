// Автентифікація та ролі (локальна, для навчального застосунку).
// Паролі — scrypt-хеш через вбудований node:crypto (без зовнішніх залежностей).
// Сесії — токени в памʼяті процесу (скидаються при перезапуску сервера).
//
// УВАГА (безпека): це достатньо для локального використання, але НЕ продакшн-рівень:
// сервер працює по HTTP без TLS, сесії зберігаються лише в RAM. Для реального розгортання
// потрібні HTTPS, постійне сховище сесій і політика паролів.
import crypto from 'node:crypto';
import { db } from './db.js';

export const ROLES = { read: 'Тільки читання', write: 'Читання / запис', supervisor: 'Адміністратор (повні права)' };

// --- схема users ---
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  pass_salt TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'read',   -- read | write | supervisor
  full_name TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT
);
`);

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function verifyPassword(password, salt, expectedHash) {
  const h = crypto.scryptSync(String(password), salt, 64);
  const e = Buffer.from(expectedHash, 'hex');
  return h.length === e.length && crypto.timingSafeEqual(h, e);
}

// дефолтний admin/admin (supervisor), якщо користувачів немає
(function seedAdmin() {
  const n = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  if (n > 0) return;
  const { salt, hash } = hashPassword('admin');
  db.prepare('INSERT INTO users(username,pass_salt,pass_hash,role,full_name,active,created_at) VALUES(?,?,?,?,?,1,?)')
    .run('admin', salt, hash, 'supervisor', 'Адміністратор', new Date().toISOString().slice(0, 10));
  console.log('[auth] Створено дефолтного користувача admin / admin (supervisor).');
})();

// --- сесії в памʼяті ---
const sessions = new Map(); // token -> { userId, username, role, full_name }

export function login(username, password) {
  const u = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(String(username || ''));
  if (!u || !verifyPassword(password, u.pass_salt, u.pass_hash)) return null;
  const token = crypto.randomBytes(24).toString('hex');
  const session = { userId: u.id, username: u.username, role: u.role, full_name: u.full_name };
  sessions.set(token, session);
  return { token, user: { username: u.username, role: u.role, full_name: u.full_name } };
}
export function logout(token) { sessions.delete(token); }
export function sessionOf(token) { return token ? sessions.get(token) || null : null; }
// прибрати всі сесії користувача (після зміни ролі/пароля/деактивації),
// окрім збереженого токена (keepToken) — щоб той, хто редагує сам себе, не вилетів.
function dropSessionsForUser(userId, keepToken = null) {
  for (const [t, s] of sessions) {
    if (s.userId === userId && t !== keepToken) sessions.delete(t);
  }
}
// оновити дані у вже наявній сесії (після зміни ролі/імені свого ж акаунта)
function refreshSession(token, patch) {
  const s = sessions.get(token);
  if (s) Object.assign(s, patch);
}

// --- middleware ---
function tokenFromReq(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : (req.query.token || null);
}
// вимагає валідної сесії; кладе req.user
export function requireAuth(req, res, next) {
  const s = sessionOf(tokenFromReq(req));
  if (!s) return res.status(401).json({ error: 'Потрібна автентифікація' });
  req.user = s;
  next();
}
// вимагає одну з дозволених ролей
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Потрібна автентифікація' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Недостатньо прав' });
    next();
  };
}

// --- CRUD користувачів (для supervisor) ---
export function listUsers() {
  return db.prepare('SELECT id,username,role,full_name,active,created_at FROM users ORDER BY username').all()
    .map(u => ({ ...u, active: !!u.active }));
}
export function createUser({ username, password, role = 'read', full_name = null }) {
  if (!username || !password) throw new Error('Потрібні логін і пароль');
  if (!ROLES[role]) throw new Error('Невідома роль');
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) throw new Error('Такий логін уже існує');
  const { salt, hash } = hashPassword(password);
  const id = db.prepare('INSERT INTO users(username,pass_salt,pass_hash,role,full_name,active,created_at) VALUES(?,?,?,?,?,1,?)')
    .run(username, salt, hash, role, full_name, new Date().toISOString().slice(0, 10)).lastInsertRowid;
  return listUsers().find(u => u.id === id);
}
// currentToken — токен того, хто виконує зміну (щоб не розлогінити себе при зміні власного акаунта).
export function updateUser(id, { role, full_name, active, password }, currentToken = null) {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!u) throw new Error('Користувача не знайдено');
  const editingSelf = currentToken && sessions.get(currentToken)?.userId === Number(id);
  // не дати деактивувати/розжалувати останнього активного supervisor
  if (u.role === 'supervisor') {
    const supers = db.prepare("SELECT COUNT(*) c FROM users WHERE role='supervisor' AND active=1").get().c;
    const losingSuper = (role && role !== 'supervisor') || (active === false || active === 0);
    if (supers <= 1 && losingSuper) throw new Error('Має лишатися щонайменше один активний адміністратор');
  }
  if (role && !ROLES[role]) throw new Error('Невідома роль');
  const newRole = role ?? u.role;
  const newName = full_name === undefined ? u.full_name : full_name;
  const newActive = active === undefined ? u.active : (active ? 1 : 0);
  let salt = u.pass_salt, hash = u.pass_hash;
  if (password) ({ salt, hash } = hashPassword(password));
  db.prepare('UPDATE users SET role=?,full_name=?,active=?,pass_salt=?,pass_hash=? WHERE id=?')
    .run(newRole, newName, newActive, salt, hash, id);
  if (role !== undefined || password || active !== undefined) {
    // зберігаємо власну сесію редактора, якщо він міняє сам себе
    dropSessionsForUser(id, editingSelf ? currentToken : null);
    if (editingSelf) refreshSession(currentToken, { role: newRole, full_name: newName });
  }
  return { ...listUsers().find(x => x.id === Number(id)), self: !!editingSelf };
}
export function deleteUser(id) {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!u) return;
  if (u.role === 'supervisor') {
    const supers = db.prepare("SELECT COUNT(*) c FROM users WHERE role='supervisor' AND active=1").get().c;
    if (supers <= 1) throw new Error('Не можна видалити останнього адміністратора');
  }
  dropSessionsForUser(id);
  db.prepare('DELETE FROM users WHERE id=?').run(id);
}
